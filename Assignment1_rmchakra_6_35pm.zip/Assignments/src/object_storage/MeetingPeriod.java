package object_storage;

public class MeetingPeriod {
	public String day;
	public Timing timing;
	public MeetingPeriod() {
		timing = new Timing();
	}

}
