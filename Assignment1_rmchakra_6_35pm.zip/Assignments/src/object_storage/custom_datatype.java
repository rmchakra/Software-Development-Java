package object_storage;

public class custom_datatype {

String longName;
String prefix;
public String getLongName() {
	return longName;
}
public void setLongName(String longName) {
	this.longName = longName;
}
public String getPrefix() {
	return prefix;
}
public void setPrefix(String prefix) {
	this.prefix = prefix;
}
}
