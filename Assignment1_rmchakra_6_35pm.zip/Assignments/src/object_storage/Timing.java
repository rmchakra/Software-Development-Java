package object_storage;

public class Timing {
	public String start;
	public String end;

}
