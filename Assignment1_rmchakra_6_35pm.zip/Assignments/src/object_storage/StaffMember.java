package object_storage;

import java.util.ArrayList;

public class StaffMember {
	public String type;
	public int id;
	public Name name;
	public String email;
	public String image;
	public String phone;
	public String office;
	public StaffMember() {
		officeHours = new ArrayList<OfficeHour> ();
		name = new Name();
	}
	public ArrayList<OfficeHour> officeHours;

}
