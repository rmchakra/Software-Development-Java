package driver;
import objects.*;
import parsing.StringConstants;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// all methods are static since unnecessary to generate object to use the methods each time
public class JDBCDriver {
	private static Connection conn = null;
	private static ResultSet rs = null;
	private static PreparedStatement ps = null;
	private static String ip;
	private static String username;
	private static String password;
	private static boolean ssl;
	
	public static void writeToDatabase(DataContainer data){
		//create the database from filled data obj
		Course course = writeCourse(data.getSchools().get(0));
		writeStaffMembers(course.getStaffMembers());
		writeMeetings(course.getMeetings());
		
		
		
		
		
		
		
		
		close();	
		
	}
	public static void readFromDatabase(DataContainer data){
//		read from database into data variable
		//do not do new DataContainer else wont reference same data obj
		
		//reading values
//		ps = conn.prepareStatement("SELECT UserID FROM course WHERE Username =?");
//		ps.setString(1, usr);
//		rs = ps.executeQuery();
//		
//		if(rs.next()){
//			println("enters if next");
//			return rs.getInt("UserID");
//		}
		

//		ps = conn.prepareStatement("SELECT "+StringConstants.SCHOOLIMAGE +" FROM "+ StringConstants.TABLECOURSE +" WHERE "+ StringConstants.SYLLABUS + " = ?");
//		ps.setString(1,course.getSyllabus().getUrl());
//		rs = ps.executeQuery();
////		
////		print();
//		if(rs.next()){
//			println("enters if next");
//			print("Should be TRUE =");
//			println(Boolean.toString(school.getImage().equals(rs.getString(StringConstants.SCHOOLIMAGE))));
//		}
	}
	private static Course writeCourse(School school){
		Department dept = school.getDepartments().get(0);
		Course course = dept.getCourses().get(0);
		//schoolName, schoolImage, departmentLongName, departmentPrefix, number, title, term, year, syllabus
		try {
			ps = conn.prepareStatement("insert into "+StringConstants.TABLECOURSE+" ("+StringConstants.SCHOOLNAME+","+ StringConstants.SCHOOLIMAGE+","+ StringConstants.DEPARTMENTLONGNAME+","+ StringConstants.DEPARTMENTPREFIX+","+ StringConstants.NUMBER+","+ StringConstants.TITLE+","+ StringConstants.TERM+","+ StringConstants.YEAR+","+ StringConstants.SYLLABUS+") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");			
			ps.setString(1, school.getName());
			ps.setString(2, school.getImage());
			ps.setString(3, dept.getLongName());
			ps.setString(4, dept.getPrefix());
			ps.setString(5, course.getNumber());
			ps.setString(6, course.getTitle());
			ps.setString(7, course.getTerm());
			ps.setInt(8, course.getYear());
			ps.setString(9, course.getSyllabus().getUrl());			
			ps.executeUpdate();//add the course table
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return course;
	}
	private static void writeStaffMembers(List<StaffMember> staffMembers){
		//type, id, fname, lname, email, image, phone, office
		
		for(StaffMember staffMember : staffMembers){
			try {
				ps = conn.prepareStatement("insert into "+ StringConstants.TABLESTAFFMEMBERS+" ("+StringConstants.TYPE+","+ StringConstants.ID+","+ StringConstants.FNAME+","+ StringConstants.LNAME+","+ StringConstants.EMAIL+","+ StringConstants.IMAGE+","+ StringConstants.PHONE+","+ StringConstants.OFFICE+") VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
				ps.setString(1, staffMember.getJobType());
				ps.setInt(2, staffMember.getID() );
				ps.setString(3, staffMember.getName().getFirstName() );
				ps.setString(4, staffMember.getName().getLastName() );
				ps.setString(5,staffMember.getEmail() );
				ps.setString(6, staffMember.getImage() );
				ps.setString(7, staffMember.getPhone() );
				ps.setString(8, staffMember.getOffice() );			
				ps.executeUpdate();
				writeOH(staffMember);
		
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	private static void writeOH(StaffMember staffMember){
		List<TimePeriod> officeHours = staffMember.getOH();
		//		ohID (not inserted),  staffId, day, start, end
		for(TimePeriod oh : officeHours){
			try {
				ps = conn.prepareStatement("insert into "+ StringConstants.TABLEOH+" ("+StringConstants.STAFFID+","+ StringConstants.DAY+","+ StringConstants.START+","+ StringConstants.END+" ) VALUES (?, ?, ?, ?)");
				ps.setInt(1, staffMember.getID() );
				ps.setString(2, oh.getDay());		
				ps.setString(3, oh.getTime().getStartTime());
				ps.setString(4, oh.getTime().getEndTime() );
				ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	}
	private static void writeMeetings(List<Meeting> meetings){
		for(Meeting meeting : meetings){
			try {
				//type, section, room
				ps = conn.prepareStatement("insert into "+ StringConstants.TABLEMEETING+" ("+StringConstants.TYPE+","+ StringConstants.SECTION+","+ StringConstants.ROOM+" ) VALUES (?, ?, ?)");
				ps.setString(1,meeting.getType() );	
				ps.setString(2, meeting.getSection());
				ps.setString(3, meeting.getRoom() );
				ps.executeUpdate();
				writeMeetingSections(meeting);
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	private static void writeMeetingSections(Meeting meeting){
		for(TimePeriod meetingPeriod : meeting.getMeetingPeriods()){
			try {
				//idmeetingPeriod (unused), day, start, end, section
				ps = conn.prepareStatement("insert into "+ StringConstants.TABLEMEETINGPERIOD+" ("+StringConstants.DAY+","+ StringConstants.START+","+ StringConstants.END+","+ StringConstants.SECTION+" ) VALUES (?, ?, ?, ?)");
				ps.setString(1,meetingPeriod.getDay() );
				ps.setString(2, meetingPeriod.getTime().getStartTime() );	
				ps.setString(3, meetingPeriod.getTime().getEndTime());
				ps.setString(4, meeting.getSection());
				ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	
	
	
	
	public static void connect(String ipPar, String usernamePar, String passwordPar, boolean sslPar){
		ip = ipPar;
		username = usernamePar;
		password = passwordPar;
		ssl = sslPar;
		
		ip = "localhost";
		username = "root";
		password = "betaLeData1";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://"+ip+"/rmchakra_201_site?user="+username+"&password="+password+"&useSSL="+Boolean.toString(ssl));		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void close(){
		try{
			if (rs!=null){
				rs.close();
				rs = null;
			}
			if(conn != null){
				conn.close();
				conn = null;
			}
			if(ps != null ){
				ps = null;
			}
		}catch(SQLException sqle){
			System.out.println("connection close error");
			sqle.printStackTrace();
		}
	}
	public static void clearTables(){
		try {
			Statement st = conn.createStatement();
			st.executeUpdate("SET FOREIGN_KEY_CHECKS = 0");
			st.executeUpdate("TRUNCATE "+ StringConstants.TABLEOH);
			st.executeUpdate("TRUNCATE "+ StringConstants.TABLECOURSE);
			st.executeUpdate("TRUNCATE "+ StringConstants.TABLESTAFFMEMBERS );
			
			st.executeUpdate("SET FOREIGN_KEY_CHECKS = 1");
			
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static boolean validate(String usr, String pwd){
//		connect();
		try {
			ps = conn.prepareStatement("SELECT password FROM User WHERE username=?");
			ps.setString(1, usr);
			rs = ps.executeQuery();
			System.out.println(rs);
			if(rs.next()){
				if(pwd.equals(rs.getString("password")) ){
					return true;
				}
			}
		} catch (SQLException e) {
			System.out.println("SQLException in function \"validate\"");
			e.printStackTrace();
		}finally{
			close();
		}
		return false;		
	}
	public static void increment(String usr, String page){
//		connect();
		try{
			ps = conn.prepareStatement("SELECT userID FROM User WHERE username =?");
			ps.setString(1, usr);
			rs = ps.executeQuery();
			int userID = -1;
			if(rs.next()){
				userID = rs.getInt("userID");
			}
			rs.close();
			ps = conn.prepareStatement("SELECT pageID FROM Page WHERE name= ?");
			ps.setString(1, page);
			rs = ps.executeQuery();
			int pageID = -1;
			
			if(rs.next()){
				pageID = rs.getInt("pageID");
			}
			rs.close();
			ps = conn.prepareStatement("SELECT count FROM PageVisited WHERE userID = '"+userID+"' AND pageID='"+pageID+"'");
			rs = ps.executeQuery();
			if(rs.equals(null)){
				System.out.println("nothing returned");
			}
			int count = -1;
			if (rs.next()){
				count = rs.getInt("count");
			}
			rs.close();
			if(count >0){
				ps = conn.prepareStatement("UPDATE pageVisited pv SET pv.count = "+(count+1)+" WHERE userID = "+userID+" AND pageID = "+pageID);
			}else{
				ps = conn.prepareStatement("INSERT INTO pageVisited (userID, pageID, count) VALUES ('"+userID+"', '"+pageID+"', 1) ");
			}
			ps.executeUpdate();
		}catch(SQLException sqle){
			System.out.println("SQLException in function \"increment\"");
			sqle.printStackTrace();
		}
		finally{
			close();
		}
	}
	public static ArrayList<ArrayList<String> >getData(){
		ArrayList<ArrayList<String>>  stat = new ArrayList<ArrayList<String>>();
//		connect();
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost/Lab10?user=root&password=root&useSSL=false");
			ps = conn.prepareStatement("SELECT u.username, p.name, pv.count FROM User u, Page p, PageVisited pv "
					+ "WHERE u.userID = pv.userID AND p.pageID = pv.pageID ORDER BY u.userID, p.pageID");
			rs = ps.executeQuery();
			while(rs.next()){
				ArrayList<String> row = new ArrayList<String>();
				row.add(rs.getString("u.username"));
				row.add(rs.getString("p.name"));
				row.add(rs.getString("pv.count"));
				stat.add(row);
			}
		}catch(SQLException sqle){
			System.out.println("SQLException in function \" getData\": ");
			sqle.printStackTrace();
		}finally{
			close();
		}
		return stat;
	}
	private static void println(String string) {
		System.out.println(string);		
	}
	private static void print(String string) {
		System.out.print(string);		
	}
}
