package parsing;

public class StringConstants {

	public static final String WRITTEN_EXAM_1 = "written exam #1";
	public static final String WRITTEN_EXAM_2 = "written exam #2";
	public static final String PROGRAMMING_EXAM_1 = "programming exam #1";
	public static final String PROGRAMMING_EXAM_2 = "programming exam #2";
	public static final String INSTRUCTOR = "instructor";
	public static final String FILE = "file";
	public static final String DATA = "data";
	public static final String HOME_JSP = "home.jsp";
	public static final String EXAMS_JSP = "exams.jsp";
	public static final String ASSIGNMENTS_JSP = "assignments.jsp";
	public static final String LECTURES_JSP = "lectures.jsp";
	public static final String LOCATION = "location";
	public static final String LECTURE = "lecture";
	public static final String LAB = "lab";
	public static final String ASCENDING = "asc";
	public static final String DESCENDING = "desc";
	public static final String TITLE = "title";
	public static final String DUE = "due";
	public static final String ASSIGNED = "assigned";
	public static final String GRADE = "grade";
	public static final String COURSE = "course";
	public static final String DELIVERABLES = "deliverables";
	public static final String ASSIGNMENTS = "assignments";
	public static final String SHOW_ALL = "all";
	public static final String SHOW_DUE = "due_dates";
	public static final String SHOW_LECTURES ="show_lectures";
	public static final String HOME ="home";
	public static final String DESIGN ="design";
	public static final String DESIGN_1 ="design_1";
	public static final String DESIGN_2 ="design_2";
	
	//tables
	public static final String TABLECOURSE = "course";
	public static final String TABLESTAFFMEMBERS = "StaffMembers";
	public static final String TABLEOH = "oh";

	
		public static final String TABLEMEETING = "meeting";
		public static final String TABLEMEETINGPERIOD = "meetingPeriod";	
	//	public static final String TABLE = "";
	//	public static final String TABLE = "";	
	//	public static final String TABLE = "";
	//	public static final String TABLE = "";	
	//	public static final String TABLE = "";
	//	public static final String TABLE = "";
	//	public static final String TABLE = "";
	//	public static final String TABLE = "";	
	//	public static final String TABLE = "";
	//	public static final String TABLE = "";	
	//	public static final String TABLE = "";
	//	public static final String TABLE = "";	
	//	public static final String TABLE = "";
	//	public static final String TABLE = "";



	
	//table column names
	//course : idcourse, schoolName, schoolImage, departmentLongName, departmentPrefix, number, title, term, year, syllabus	
	public static final String IDCOURSE = "idcourse";
	public static final String SCHOOLNAME = "schoolName";
	public static final String SCHOOLIMAGE = "schoolImage";
	public static final String DEPARTMENTLONGNAME = "departmentLongName";
	public static final String DEPARTMENTPREFIX = "departmentPrefix" ;
	public static final String NUMBER = "number";
	public static final String TERM = "term";
	public static final String YEAR = "year";
	public static final String SYLLABUS= "syllabus";
	//StaffMembers : type, id, fname, lname, email, image, phone, office
		public static final String TYPE= "type" ;
		public static final String ID = "id";
		public static final String FNAME  = "fname";
		public static final String  LNAME = "lname";
		public static final String EMAIL= "email";
		public static final String IMAGE  ="image";
		public static final String PHONE = "phone";
		public static final String  OFFICE= "office";
//		OH : ohID,  staffId, day, start, end
		public static final String OHID= "ohID";
		public static final String STAFFID = "staffId";
		public static final String DAY= "day" ;
		public static final String  START= "start";
		public static final String  END= "end";
//		meeting: type, section, room
		public static final String SECTION = "section";
		public static final String ROOM ="room";
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;	
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;
	//	public static final String ;

		
	
	
}
