package objects;

import java.util.List;

public class Assignment extends GeneralAssignment {
	
	private String url;
	private List<File> gradingCriteriaFiles;
	private List<File> solutionFiles;
	private List<Deliverable> deliverables;
	// already has var : files since inherits from general assignment,
	
	public String getUrl() {
		return url;
	}

	public List<Deliverable> getDeliverables() {
		return deliverables;
	}

	public List<File> getGradingCriteriaFiles() {
		return gradingCriteriaFiles;
	}

	public List<File> getSolutionFiles() {
		return solutionFiles;
	}

}
