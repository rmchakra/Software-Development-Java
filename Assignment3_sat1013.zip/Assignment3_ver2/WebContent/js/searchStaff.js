function searchStaff(){
//				document.getElementById("button result").innerHTML = document.searchStaff.staffMemberQuery.value;
				document.getElementById("button result").innerHTML = "search staff";
//				System.out.println("search staff");
				/* return false; */
			}
function clearStaff(){
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "../SearchStaffServlet?staffMemberQuery="+document.searchStaff.staffMemberQuery.value, false);
	xhttp.send(); 
	document.getElementById("button result").innerHTML = xhttp.responseText;
	var fullName = xhttp.responseText;
	document.getElementById(fullName).style.backgroundColor= "lightblue";
			}