function LectureQueryFunc(){
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "lectureSearch.jsp?lectureQuery="+document.searchlecform.LectureQuery.value, true);
		xhttp.send(); 
	
	
	xhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
		    
			  var ls = 	xhttp.responseText;	
			  document.getElementById("lectureContent").innerHTML = ls;
				
				
		  }
		};

}
function lecClearFunc(){

	var xhttp = new XMLHttpRequest();
	
	xhttp.open("GET", "lectureSearch.jsp?lectureQuery=99999999", true);
		xhttp.send(); 
	
	
	xhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
		    
			  var ls = 	xhttp.responseText;	
			  document.getElementById("lectureContent").innerHTML = ls;
				
				
		  }
		};

}