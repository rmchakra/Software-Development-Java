package objects;

//inherits from GeneralAssignment class
public class Deliverable extends GeneralAssignment{
}
