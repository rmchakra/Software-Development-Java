package gamePackage;

import java.util.Vector;
import java.util.concurrent.ThreadLocalRandom;

import networking.*;

public class Game {
	String gameName = "no game name";
	ServerThread creator;
	int awaitingPlayers = 0;
	Vector<ServerThread> players;
	Vector<Card> deck;
	public Vector<Card> getDealerCards() {
		return dealerCards;
	}

	public void setDealerCards(Vector<Card> dealerCards) {
		this.dealerCards = dealerCards;
	}

	Vector<Card> dealerCards;
	public Card takeCard(){
		int randomNum = ThreadLocalRandom.current().nextInt(0,  deck.size());
		return deck.remove(randomNum);
		
		
	}
	public void resetDeck(){
		deck = Card.create_deck();
	}
	
	public ServerThread getCreator() {
		return creator;
	}
	public void setCreator(ServerThread creator) {
		this.creator = creator;
	}
	public int getAwaitingPlayers() {
		return awaitingPlayers;
	}
	public void setAwaitingPlayers(int awaitingPlayers) {
		this.awaitingPlayers = awaitingPlayers;
	}
	public Vector<ServerThread> getPlayers() {
		return players;
	}
	public void setPlayers(Vector<ServerThread> players) {
		this.players = players;
	}
	public void addPlayer(ServerThread player) {
		players.add(player);
	}

	public Game(String gameName, ServerThread creator, int awaitingPlayers) {
		super();
		this.gameName = gameName;
		this.awaitingPlayers = awaitingPlayers;
		this.creator= creator;
		players = new Vector<ServerThread>();
		addPlayer(creator);
		deck = Card.create_deck();
		
	}

	public Vector<Card> getDeck() {
		return deck;
	}
	public void setDeck(Vector<Card> deck) {
		this.deck = deck;
	}
	public int getawaitingPlayers() {
		return awaitingPlayers;
	}

	public void setawaitingPlayers(int awaitingPlayers) {
		this.awaitingPlayers = awaitingPlayers;
	}


	public String getGameName() {
		return gameName;
	}

	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
}
