package gamePackage;

import java.util.Vector;

import networking.gameRoom;

public class Card {

	private String suit;
	private String name;// ace or what
	private int value;
	public String getSuit() {
		return suit;
	}
	public void setSuit(String suit) {
		this.suit = suit;
	}
	public Card(String suit, String name, int value) {
		super();
		this.suit = suit;
		this.value = value;
		this.name = name;
	}
	//Method is static since can be called without creating an instance of card
	//function: gives a comlete deck of cards. No inputs. output : deck of 52 cards
	public static Vector<Card> create_deck(){
		Vector<Card> deck = new Vector<Card>();
		 String[] suits = { "Spades", "Hearts", "Diamonds", "Clubs"};
		 String[] cards = { "Ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King"};
		 for(String suitI: suits){
			 for(String card : cards){
				 Card c;
				 if(card.equals("Ace")){
//					 System.out.println("within loop values"+suitI + " "+card);
						 c = new Card(suitI, card, 11);
				 }else if(card.equals("Jack") ||card.equals("Queen") ||card.equals("King") ){
//					 System.out.println("within loop values"+suitI + " "+card);
						c = new Card(suitI, card, 10);
				 }else{
//					 System.out.println("within loop values"+suitI + " "+card);
					 c = new Card(suitI, card, Integer.parseInt(card));
				 }
				
				 deck.add(c);
			 }
		 }
		return deck;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getValue() {
		return value;
	}
	public void setValue(int value) {
		this.value = value;
	}
	public static void main(String [] args) {
		create_deck();
	}
}
