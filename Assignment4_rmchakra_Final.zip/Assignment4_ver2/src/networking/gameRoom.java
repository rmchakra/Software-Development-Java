package networking;
import gamePackage.*;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.util.Vector;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Vector;

public class gameRoom {//Server

	private Vector<ServerThread> serverThreads;
	private Vector<Game> games;
	public Vector<Game> getGames() {
		return games;
	}

	public void setGames(Vector<Game> games) {
		this.games = games;
	}
	public void addGame(Game game) {
		games.add(game);
	}

	public gameRoom(int port) {
		try {
			System.out.println("Binding to port " + port);
			ServerSocket ss = new ServerSocket(port);
			System.out.println("Bound to port " + port);
			serverThreads = new Vector<ServerThread>();
			games = new Vector<Game>();
//			int maxPlayerCount = 1;
			while(true){
				Socket s = ss.accept(); // keeps accepting connections
				System.out.println("Connection from: " + s.getInetAddress());
				
				
				ServerThread st = new ServerThread(s, this);
				serverThreads.add(st);
			}
			
			
//			while(true) {
//				;
//			}
		} catch (IOException ioe) {
			System.out.println("Invalid port. Please re-enter");
		}
	}
	
//	public void broadcast(String message, ServerThread st) {
	public void broadcast(ChatMessage cm, ServerThread st) {
		//if (message != null) {
		if (cm != null) {
			//System.out.println(message);
			System.out.println(cm.getUsername() + ": " + cm.getMessage());
			for(ServerThread threads : serverThreads) {
				if (st != threads) {
					//threads.sendMessage(message);
					threads.sendMessage(cm);
				}
			}
		}
	}
	
	public static void main(String [] args) {
		Scanner scan = new Scanner(System.in);
		while(true){
			System.out.println("Input port");
			try{
				int port = scan.nextInt();
				gameRoom gr = new gameRoom(port);
			}catch(Exception e){
				System.out.println("Invalid port. Please re-enter");
			}
			
		}
		
	}
}