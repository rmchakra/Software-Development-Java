package networking;
import gamePackage.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Vector;

import constants.Constants;

public class ServerThread extends Thread {

	//private PrintWriter pw;
	//private BufferedReader br;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private gameRoom gr;
	private Constants constants;
	private String userName;
	private String gameName;
	private int playerIndex;
	private int bet;
	private int status;
	private Vector<Card> cards;
	private int chips;
	
 	public int getPlayerIndex() {
		return playerIndex;
	}
	public void setPlayerIndex(int playerIndex) {
		this.playerIndex = playerIndex;
	}
	public int getBet() {
		return bet;
	}
	public void setBet(int bet) {
		this.bet = bet;
	}
	public Vector<Card> getCards() {
		return cards;
	}
	public void setCards(Vector<Card> cards) {
		this.cards = cards;
	}
	//function: constructor. No inputs or outputs
	public ServerThread(Socket s, gameRoom gr) {
 		cards = new Vector<Card>(); chips = 500;
 		constants = new Constants();
		try {
			this.gr = gr;
			//pw = new PrintWriter(s.getOutputStream());
			//br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			oos = new ObjectOutputStream(s.getOutputStream());
			ois = new ObjectInputStream(s.getInputStream());
			this.start();
		} catch (IOException ioe) {
			System.out.println("ioe in ServerThread constructor: " + ioe.getMessage());
		}
	}
 	public void startGame(){
 		bet();
 		
// 		inputMoves();
 	}
 	//function: take moves from player and bounce back to all the clients. No inputs or outputs
 	private void inputMoves(){
// 		print("input moves player:"+userName);
 		ChatMessage msg = new ChatMessage(userName, "no msg");
	 	int gameIndex = findGame(); gr.getGames().get(gameIndex).resetDeck();//resetting deck for new round
 		if(userName.equals(gr.getGames().get(gameIndex).getCreator().getUserName())){//is the creator of the game
 			//giving dealer 2 cards
 			Vector<Card> pickedCards = new Vector <Card>();
				//taking 2 cards from deck
				pickedCards.add(gr.getGames().get(gameIndex).takeCard());pickedCards.add(gr.getGames().get(gameIndex).takeCard());
				//adding to dealer
				gr.getGames().get(gameIndex).setDealerCards(pickedCards);
 			
 			//assigning 2 cards to each player - doing to copy not original
			for(int i =0; i< gr.getGames().get(gameIndex).getPlayers().size();i++){// adding 2 cards to every player
	 			pickedCards = new Vector <Card>();
	 			//taking 2 cards from deck
	 			pickedCards.add(gr.getGames().get(gameIndex).takeCard());pickedCards.add(gr.getGames().get(gameIndex).takeCard());
	 			gr.getGames().get(gameIndex).getPlayers().get(i).setCards(pickedCards);
	 		}
 			//sending all players the initial state
 			msg.setMessage(gameState(gr.getGames().get(gameIndex)));//sending the game			
 	 		sendMessageAll(msg);// message all playername bet chips
 			
 		}

 	 	try {msg = (ChatMessage) ois.readObject();} catch (ClassNotFoundException | IOException e) {e.printStackTrace();}
		//wait for UI received by client
 	 	ChatMessage cm = new ChatMessage(userName, gr.getGames().get(gameIndex).getCreator().getUserName());
 	 	sendMessage(cm);//sending creator's turn
 		while(true){
 			try {msg = (ChatMessage) ois.readObject();} catch (ClassNotFoundException | IOException e) {e.printStackTrace();}
 			//waits to receive move from client
 			String move = msg.getMessage();
 			if(move.equals(constants.stay)){msg.setMessage(msg.getUsername()+" "+msg.getMessage());}//if user decides to stay
 			else{//if user decides to hit
 				Card hitCard = gr.getGames().get(gameIndex).takeCard();
 				cards.add(hitCard); status+=(hitCard.getValue());
// 				if(status>21){
// 					for(Card ch : cards){
// 						if(ch.getName().equals("Ace")){
// 							status-=10; break;//only minusing for 1 ace rn
// 						}
// 					}
// 				}
 			}
 			sendMessageAll(msg);//send move to all clients
 			try {msg = (ChatMessage) ois.readObject();} catch (ClassNotFoundException | IOException e) {e.printStackTrace();}
 			//waits to confirm that move received and printed
 			//messaging next user's turn
 			if(move.equals(constants.stay) || status>21){
 				//if stay or bust
 				if(userName.equals(gr.getGames().get(gameIndex).getPlayers().get(gr.getGames().get(gameIndex).getPlayers().size()-1).getUserName())){
 					//if reached last player then playing moves round ends
 					msg.setMessage(constants.endInputMoves);
 					sendMessageAll(msg);
 				}
 				else{//sending next player's name
 					msg.setMessage(gr.getGames().get(gameIndex).getPlayers().get(playerIndex+1).getUserName());
 					sendMessageAll(msg);
 				}
 			}else{//your move again since didnt bust so sending your name
 				msg.setMessage(userName);
					sendMessageAll(msg);
 			}
 			
 			
 			
 		}
 	}
 	//function: take bet from client. No inputs or outputs
 	private void bet(){
 		int gameIndex = findGame();
 		ChatMessage cm = new ChatMessage(userName, gr.getGames().get(gameIndex).getCreator().getUserName());
// 		cm.setUsername(Integer.toString(gr.getGames().get(gameIndex).getCreator().getChips()));
 		sendMessage(cm);//sending creator
 		try {cm = (ChatMessage)ois.readObject();} catch (ClassNotFoundException | IOException e) {e.printStackTrace();}
		//receiving bet
 		print("receiving bet");
 		bet = Integer.parseInt(cm.getMessage());
 		cm.setUsername(userName);
 		cm.setMessage(userName + " bet "+ bet+ " chips");			
 		sendMessageAll(cm);// message all playername bet chips
 		if(userName.equals(gr.getGames().get(gameIndex).getPlayers().get(gr.getGames().get(gameIndex).getPlayers().size()-1).getUserName())){
 			//if this is the last player to join the game
 			try {cm = (ChatMessage)ois.readObject();} catch (ClassNotFoundException | IOException e) {e.printStackTrace();}
 			
 			cm.setMessage(constants.endBetting);
 			sendMessageAll(cm);
 		}
 		else{
 			try {cm = (ChatMessage)ois.readObject();} catch (ClassNotFoundException | IOException e) {e.printStackTrace();}
 			cm.setUsername(userName);
 			cm.setMessage(gr.getGames().get(gameIndex).getPlayers().get(playerIndex+1).getUserName());
 			sendMessageAll(cm);
 		}
 		
 	}
 	//function: so I dont need to type system.out.print each time input string output none only prints to console
public void print(String s){
 		System.out.println(s);
 	}
	//public void sendMessage(String message) {
//function: message all users of game. input : message to send no outputs	
public void sendMessageAll(ChatMessage cm){
		int gameIndex =findGame();
		for(ServerThread player: gr.getGames().get(gameIndex).getPlayers()){//
 			player.sendMessage(cm);
 		}
	}
//function: get the game relevant to the client. No inputs. outputs: returns index of game from array of all the games	
private int findGame(){
		int gameIndex = 0;
		for(;  gameIndex<gr.getGames().size(); gameIndex++){
			if(gr.getGames().get(gameIndex).getGameName().equals(gameName)){return gameIndex;}
		}//find game
		return -1;
	}
//function: send message to the user. input message to send. no outputs 	
public void sendMessage(ChatMessage cm) {
//		pw.println(message);
//		pw.flush();
		try {
			oos.writeObject(cm);
			oos.flush();
		} catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
	}
//function: searches and sees if the gamename chosen by a user doesnt already exist in the database. inputs :name of game as message no outputs	
private void isUniqueGameName(ChatMessage cm){
		gameName = cm.getMessage();
		Vector<Game> games = gr.getGames();
		cm.setMessage("true");//is unique
		for(Game game : games){
			if(game.getGameName().equals(gameName)){
				cm.setMessage("false");
			}
		}
		
		cm.setUsername("from server gamename :"+gameName );
		sendMessage(cm);
	}
//function: try to join a game. inputs message with name of game and username chosen	
private void joinAttempt(ChatMessage cm){
		gameName = cm.getMessage();
		int gameIndex = findGame();
		//check for valid username
		cm.setMessage(constants.usernameUnique);
		for(ServerThread player: gr.getGames().get(gameIndex).getPlayers()){
			if(cm.getUsername().equals(player.getUserName())){
//				System.out.println("username exists");
				cm.setMessage(constants.usernameExists);
			}
		}
		sendMessage(cm);//message to the specific client trying to join whether unique username or not
		
		if(cm.getMessage().equals(constants.usernameUnique)){
//			System.out.println("enters unique username in serverthread");
//			System.out.println("unique username :"+ cm.getUsername());
			userName = cm.getUsername();
			playerIndex = gr.getGames().get(gameIndex).getPlayers().size();
			gr.getGames().get(gameIndex).setAwaitingPlayers(gr.getGames().get(gameIndex).getAwaitingPlayers()-1);
			gr.getGames().get(gameIndex).addPlayer(this);
			gr.getGames().get(gameIndex).getCreator().sendMessage(cm);//send message to creator of game that new player joined
			if(gr.getGames().get(gameIndex).getawaitingPlayers()==0){//time to start the game
				startGame();
			}
		}
		
//		cm.setUsername("from server gamename :"+gameName );
		
	}
	public gameRoom getGr() {
		return gr;
	}
	public void setGr(gameRoom gr) {
		this.gr = gr;
	}
	public Constants getConstants() {
		return constants;
	}
	public void setConstants(Constants constants) {
		this.constants = constants;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getGameName() {
		return gameName;
	}
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	//function: finding game if exists. No inputs or outputs	
private void findGame(ChatMessage cm){
		String gameName = cm.getMessage();
		cm.setMessage("false");//game trying to join doesnt exist
		int gameIndex = 0;
		for(;  gameIndex<gr.getGames().size(); gameIndex++){
			if(gr.getGames().get(gameIndex).getGameName().equals(gameName)){
				if(gr.getGames().get(gameIndex).getawaitingPlayers()>0){//if waiting players not decrementing since doesnt actually join
					cm.setMessage("true");
					 break;				
				}
				
			}
		}
		cm.setUsername("from server gamename :"+gameName );
		sendMessage(cm);//message to the specific client trying to join
		
	}
//function: creates a new game. No chatmessage with gamename and username	
private void usernamePlayers(ChatMessage cm){
		userName = cm.getUsername();
		Game g = new Game(gameName, this, Integer.parseInt(cm.getMessage()));
		gr.addGame(g);//new game added
		playerIndex = 0;
		if(Integer.parseInt(cm.getMessage()) == 0){
			startGame();
		}
	}
//function: reads in the messages and sends to appropriate function no inputs or outputs.
	public void run() {
		try {
			while(true) {
				//String line = br.readLine();
				//cr.broadcast(line, this);
				ChatMessage cm = (ChatMessage)ois.readObject();//blocking till it reads the message
				if(cm.getType().equals(constants.uniqueGameName)){//checking gameName
					isUniqueGameName(cm);
				}
//				cm = (ChatMessage)ois.readObject();//blocking till it reads the message
				if(cm.getType().equals(constants.findGame)){//does game trying to join exist
					findGame(cm);
				}
				if(cm.getType().equals(constants.joinGame)){//joining game
					joinAttempt(cm);
				}
//				cm = (ChatMessage)ois.readObject();//blocking till it reads the message
				if(cm.getType().equals(constants.usernamePlayers)){//giving creator and max players for new game and adding it
					usernamePlayers(cm);
				}
				if(cm.getType().equals(constants.startGame)){//giving creator and max players for new game and adding it
					startGame();
				}
				if(cm.getType().equals(constants.inputMoves)){//giving creator and max players for new game and adding it
					inputMoves();
				}
				
				else{
//					gr.broadcast(cm, this);
				}
				
			}
		} catch (IOException ioe) {
			System.out.println("ioe in ServerThread.run(): " + ioe.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.out.println("cnfe: " + cnfe.getMessage());
		}
	}
	//function: gives current state of game. input game to print output : state of game as string
	private String gameState(Game g){
		status = 0;//resetting status for new round
		String s ="";
		Card c;
		String betweenPlayers ="------------------------------------------------\n";
		s+= betweenPlayers;s+="DEALER \n \n";
		s+="Cards: | ? | ";
		c = g.getDealerCards().get(1);
		s+= (c.getName() +" of "+ c.getSuit()); 
		//dealer cards added
		
		for(int i = 0; i<g.getPlayers().size();i++){
			ServerThread player =g.getPlayers().get(i);
			s+= (betweenPlayers+ betweenPlayers);
			s+=("Player: "+ player.getUserName());s+=("\n \n ");
			
			for(Card playerCard: player.getCards()){
				g.getPlayers().get(i).setStatus(g.getPlayers().get(i).getStatus()+playerCard.getValue());
			}
			s+=("Status: " +g.getPlayers().get(i).getStatus() +"\n");
			s+=("Cards: ");
			for(Card playerCard: player.getCards()){
				s+=(" | "+(playerCard.getName() +" of "+ playerCard.getSuit()) +" | ");
			}s+="\n";
			s+=("Chip Total: " + chips); s+=("| Bet Amount: "+ bet + "\n");
		}
		
		
		
		return s;
	}
	public int getChips() {
		return chips;
	}
	public void setChips(int chips) {
		this.chips = chips;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	
}