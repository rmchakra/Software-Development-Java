package constants;

public class Constants {
	//all public as only used as constants not modified
	public String uniqueGameName = "unique game name";
	public String joinGame = "join game";
	public String findGame = "find game";
	public String usernamePlayers = "usernamePlayers";
	public String usernameExists = "username exists";
	public String usernameUnique = "username unique";
	public String startGame = "start game";
	public String endBetting = "endBetting not a username";
	public String endInputMoves = "endInputMoves";
	public String hit ="hit";
	public String stay = "stay";
	public String inputMoves = "InputMoves";
}
