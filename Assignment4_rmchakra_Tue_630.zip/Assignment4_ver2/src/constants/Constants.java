package constants;

public class Constants {
	
	public String uniqueGameName = "unique game name";
	public String joinGame = "join game";
	public String findGame = "find game";
	public String usernamePlayers = "usernamePlayers";
	public String usernameExists = "username exists";
	public String usernameUnique = "username unique";
	public String startGame = "start game";
	public String endBetting = "endBetting not a username";
}
