package networking;
import gamePackage.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Vector;

import constants.Constants;

public class ServerThread extends Thread {

	//private PrintWriter pw;
	//private BufferedReader br;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private gameRoom gr;
	private Constants constants;
	private String userName;
	private String gameName;
	private int playerIndex;
	private int bet;
	
 	public ServerThread(Socket s, gameRoom gr) {
		constants = new Constants();
		try {
			this.gr = gr;
			//pw = new PrintWriter(s.getOutputStream());
			//br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			oos = new ObjectOutputStream(s.getOutputStream());
			ois = new ObjectInputStream(s.getInputStream());
			this.start();
		} catch (IOException ioe) {
			System.out.println("ioe in ServerThread constructor: " + ioe.getMessage());
		}
	}
 	public void startGame(){
 		bet();inputMoves();
 	}
 	private void inputMoves(){
// 		print("input moves player:"+userName);
 		ChatMessage msg = new ChatMessage(userName, "no msg");
	 	int gameIndex = findGame();
 		if(userName.equals(gr.getGames().get(gameIndex).getCreator().getUserName())){//is the creator of the game
 			
 		}

 	 	try {msg = (ChatMessage) ois.readObject();} catch (ClassNotFoundException | IOException e) {e.printStackTrace();}
		//wait for UI received by client
 	 	ChatMessage cm = new ChatMessage(userName, gr.getGames().get(gameIndex).getCreator().getUserName());
 	 	
 		while(true){
 			
 		}
 	}
 	private void bet(){
 		int gameIndex = findGame();
 		ChatMessage cm = new ChatMessage(userName, gr.getGames().get(gameIndex).getCreator().getUserName());
 		sendMessage(cm);//sending creator
 		try {cm = (ChatMessage)ois.readObject();} catch (ClassNotFoundException | IOException e) {e.printStackTrace();}
		//receiving bet
 		print("receiving bet");
 		bet = Integer.parseInt(cm.getMessage());
 		cm.setUsername(userName);
 		cm.setMessage(userName + " bet "+ bet+ " chips");			
 		sendMessageAll(cm);// message all playername bet chips
 		if(userName.equals(gr.getGames().get(gameIndex).getPlayers().get(gr.getGames().get(gameIndex).getPlayers().size()-1).getUserName())){
 			//if this is the last player to join the game
 			try {cm = (ChatMessage)ois.readObject();} catch (ClassNotFoundException | IOException e) {e.printStackTrace();}
 			
 			cm.setMessage(constants.endBetting);
 			sendMessageAll(cm);
 		}
 		else{
 			try {cm = (ChatMessage)ois.readObject();} catch (ClassNotFoundException | IOException e) {e.printStackTrace();}
 			
 			print(userName+ " thread entered else");
 			cm.setUsername(userName);
 			cm.setMessage(gr.getGames().get(gameIndex).getPlayers().get(playerIndex+1).getUserName());
 			sendMessageAll(cm);
 		}
 		
 	}
 	public void print(String s){
 		System.out.println(s);
 	}
	//public void sendMessage(String message) {
	public void sendMessageAll(ChatMessage cm){
		int gameIndex =findGame();
		for(ServerThread player: gr.getGames().get(gameIndex).getPlayers()){//
 			player.sendMessage(cm);
 		}
	}
	private int findGame(){
		int gameIndex = 0;
		for(;  gameIndex<gr.getGames().size(); gameIndex++){
			if(gr.getGames().get(gameIndex).getGameName().equals(gameName)){return gameIndex;}
		}//find game
		return -1;
	}
 	public void sendMessage(ChatMessage cm) {
//		pw.println(message);
//		pw.flush();
		try {
			oos.writeObject(cm);
			oos.flush();
		} catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
	}
	private void isUniqueGameName(ChatMessage cm){
		gameName = cm.getMessage();
		Vector<Game> games = gr.getGames();
		cm.setMessage("true");//is unique
		for(Game game : games){
			if(game.getGameName().equals(gameName)){
				cm.setMessage("false");
			}
		}
		
		cm.setUsername("from server gamename :"+gameName );
		sendMessage(cm);
	}
	private void joinAttempt(ChatMessage cm){
		gameName = cm.getMessage();
		int gameIndex = findGame();
//		for(;  gameIndex<gr.getGames().size(); gameIndex++){
//			if(gr.getGames().get(gameIndex).getGameName().equals(gameName)){//not checking if awaiting players since already done in last step
////				gr.getGames().get(gameIndex).setawaitingPlayers(gr.getGames().get(gameIndex).getawaitingPlayers()-1);
//					 break;				
//				
//				
//			}
//		}
		
		//check for valid username
		cm.setMessage(constants.usernameUnique);
		for(ServerThread player: gr.getGames().get(gameIndex).getPlayers()){
			if(cm.getUsername().equals(player.getUserName())){
//				System.out.println("username exists");
				cm.setMessage(constants.usernameExists);
			}
		}
		sendMessage(cm);//message to the specific client trying to join whether unique username or not
		
		if(cm.getMessage().equals(constants.usernameUnique)){
//			System.out.println("enters unique username in serverthread");
//			System.out.println("unique username :"+ cm.getUsername());
			userName = cm.getUsername();
			playerIndex = gr.getGames().get(gameIndex).getPlayers().size();
			gr.getGames().get(gameIndex).setAwaitingPlayers(gr.getGames().get(gameIndex).getAwaitingPlayers()-1);
			gr.getGames().get(gameIndex).addPlayer(this);
			gr.getGames().get(gameIndex).getCreator().sendMessage(cm);//send message to creator of game that new player joined
			if(gr.getGames().get(gameIndex).getawaitingPlayers()==0){//time to start the game
				startGame();
			}
		}
		
//		cm.setUsername("from server gamename :"+gameName );
		
	}
	public gameRoom getGr() {
		return gr;
	}
	public void setGr(gameRoom gr) {
		this.gr = gr;
	}
	public Constants getConstants() {
		return constants;
	}
	public void setConstants(Constants constants) {
		this.constants = constants;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getGameName() {
		return gameName;
	}
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	private void findGame(ChatMessage cm){
		String gameName = cm.getMessage();
		cm.setMessage("false");//game trying to join doesnt exist
		int gameIndex = 0;
		for(;  gameIndex<gr.getGames().size(); gameIndex++){
			if(gr.getGames().get(gameIndex).getGameName().equals(gameName)){
				if(gr.getGames().get(gameIndex).getawaitingPlayers()>0){//if waiting players not decrementing since doesnt actually join
					cm.setMessage("true");
					 break;				
				}
				
			}
		}
		cm.setUsername("from server gamename :"+gameName );
		sendMessage(cm);//message to the specific client trying to join
		
	}
	private void usernamePlayers(ChatMessage cm){
		userName = cm.getUsername();
		Game g = new Game(gameName, this, Integer.parseInt(cm.getMessage()));
		gr.addGame(g);//new game added
		playerIndex = 0;
		if(Integer.parseInt(cm.getMessage()) == 0){
			startGame();
		}
	}
	public void run() {
		try {
			while(true) {
				//String line = br.readLine();
				//cr.broadcast(line, this);
				ChatMessage cm = (ChatMessage)ois.readObject();//blocking till it reads the message
				if(cm.getType().equals(constants.uniqueGameName)){//checking gameName
					isUniqueGameName(cm);
				}
//				cm = (ChatMessage)ois.readObject();//blocking till it reads the message
				if(cm.getType().equals(constants.findGame)){//does game trying to join exist
					findGame(cm);
				}
				if(cm.getType().equals(constants.joinGame)){//joining game
					joinAttempt(cm);
				}
//				cm = (ChatMessage)ois.readObject();//blocking till it reads the message
				if(cm.getType().equals(constants.usernamePlayers)){//giving creator and max players for new game and adding it
					usernamePlayers(cm);
				}
				if(cm.getType().equals(constants.startGame)){//giving creator and max players for new game and adding it
					startGame();
				}
				
				else{
//					gr.broadcast(cm, this);
				}
				
			}
		} catch (IOException ioe) {
			System.out.println("ioe in ServerThread.run(): " + ioe.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.out.println("cnfe: " + cnfe.getMessage());
		}
	}
}