package object_storage;

public class OfficeHour {

	public String day;
	public Timing timing;
	public OfficeHour() {
		timing = new Timing();		
	}
}
