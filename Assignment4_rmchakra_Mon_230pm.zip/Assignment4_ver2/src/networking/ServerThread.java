package networking;
import gamePackage.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Vector;

import constants.Constants;

public class ServerThread extends Thread {

	//private PrintWriter pw;
	//private BufferedReader br;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private gameRoom gr;
	private Constants constants;
	private String userName;
	private String gameName;
	
 	public ServerThread(Socket s, gameRoom gr) {
		constants = new Constants();
		try {
			this.gr = gr;
			//pw = new PrintWriter(s.getOutputStream());
			//br = new BufferedReader(new InputStreamReader(s.getInputStream()));
			oos = new ObjectOutputStream(s.getOutputStream());
			ois = new ObjectInputStream(s.getInputStream());
			this.start();
		} catch (IOException ioe) {
			System.out.println("ioe in ServerThread constructor: " + ioe.getMessage());
		}
	}

	//public void sendMessage(String message) {
	public void sendMessage(ChatMessage cm) {
//		pw.println(message);
//		pw.flush();
		try {
			oos.writeObject(cm);
			oos.flush();
		} catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
	}
	private void isUniqueGameName(ChatMessage cm){
		gameName = cm.getMessage();
		Vector<Game> games = gr.getGames();
		cm.setMessage("true");//is unique
		for(Game game : games){
			if(game.getGameName().equals(gameName)){
				cm.setMessage("false");
			}
		}
		
		cm.setUsername("from server gamename :"+gameName );
		sendMessage(cm);
	}
	
	private void joinAttempt(ChatMessage cm){
		String gameName = cm.getMessage();
		int gameIndex = 0;
		for(;  gameIndex<gr.getGames().size(); gameIndex++){
			if(gr.getGames().get(gameIndex).getGameName().equals(gameName)){//not checking if awaiting players since already done in last step
//				gr.getGames().get(gameIndex).setawaitingPlayers(gr.getGames().get(gameIndex).getawaitingPlayers()-1);
					 break;				
				
				
			}
		}
		
		//check for valid username
		cm.setMessage(constants.usernameUnique);
		for(ServerThread player: gr.getGames().get(gameIndex).getPlayers()){
			if(cm.getUsername().equals(player.getUserName())){
//				System.out.println("username exists");
				cm.setMessage(constants.usernameExists);
			}
		}
		sendMessage(cm);//message to the specific client trying to join whether unique username or not
		
		if(cm.getMessage().equals(constants.usernameUnique)){
//			System.out.println("enters unique username in serverthread");
//			System.out.println("unique username :"+ cm.getUsername());
			gr.getGames().get(gameIndex).setAwaitingPlayers(gr.getGames().get(gameIndex).getAwaitingPlayers()-1);
			gr.getGames().get(gameIndex).addPlayer(this);
			gr.getGames().get(gameIndex).getCreator().sendMessage(cm);//send message to creator of game that new player joined
			if(gr.getGames().get(gameIndex).getawaitingPlayers()==0){//time to start the game
				
			}
		}
		
//		cm.setUsername("from server gamename :"+gameName );
		
	}
	public gameRoom getGr() {
		return gr;
	}
	public void setGr(gameRoom gr) {
		this.gr = gr;
	}
	public Constants getConstants() {
		return constants;
	}
	public void setConstants(Constants constants) {
		this.constants = constants;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getGameName() {
		return gameName;
	}
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	private void findGame(ChatMessage cm){
		String gameName = cm.getMessage();
		cm.setMessage("false");//game trying to join doesnt exist
		int gameIndex = 0;
		for(;  gameIndex<gr.getGames().size(); gameIndex++){
			if(gr.getGames().get(gameIndex).getGameName().equals(gameName)){
				if(gr.getGames().get(gameIndex).getawaitingPlayers()>0){//if waiting players not decrementing since doesnt actually join
					cm.setMessage("true");
					 break;				
				}
				
			}
		}
		cm.setUsername("from server gamename :"+gameName );
		sendMessage(cm);//message to the specific client trying to join
		
	}
	private void usernamePlayers(ChatMessage cm){
		userName = cm.getUsername();
		Game g = new Game(gameName, this, Integer.parseInt(cm.getMessage())-1 );
		gr.addGame(g);//new game added
	}
	public void run() {
		try {
			while(true) {
				//String line = br.readLine();
				//cr.broadcast(line, this);
				ChatMessage cm = (ChatMessage)ois.readObject();//blocking till it reads the message
				if(cm.getType().equals(constants.uniqueGameName)){//checking gameName
					isUniqueGameName(cm);
				}
//				cm = (ChatMessage)ois.readObject();//blocking till it reads the message
				if(cm.getType().equals(constants.findGame)){//does game trying to join exist
					findGame(cm);
				}
				if(cm.getType().equals(constants.joinGame)){//joining game
					joinAttempt(cm);
				}
//				cm = (ChatMessage)ois.readObject();//blocking till it reads the message
				if(cm.getType().equals(constants.usernamePlayers)){//giving creator and max players for new game and adding it
					usernamePlayers(cm);
				}
				
				
				else{
//					gr.broadcast(cm, this);
				}
				
			}
		} catch (IOException ioe) {
			System.out.println("ioe in ServerThread.run(): " + ioe.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.out.println("cnfe: " + cnfe.getMessage());
		}
	}
}