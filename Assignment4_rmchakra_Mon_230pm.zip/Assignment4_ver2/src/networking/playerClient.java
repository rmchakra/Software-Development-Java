package networking;

import constants.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class playerClient extends Thread {

	//private BufferedReader br;
	//private PrintWriter pw;
	private Constants constants;
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	private String userName;
	private String gameName;
	
	public playerClient() {
		constants = new Constants();
		connect();
		gameChoice();
		Scanner scan = new Scanner (System.in);
//		this.start();
//		while(true) {
//			String line = scan.nextLine();
//			ChatMessage cm = new ChatMessage(userName, line);
//			try {
//				oos.writeObject(cm);
//				oos.flush();
//			} catch (IOException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			//pw.println("Donald: " + line);
			//pw.flush();
//		}
		
	}
	private void gameChoice(){

//		System.out.println("enters gamechoice");
//		newGame();
		joinGame();//rn never going to reach since ng is forever loop
	}
	private void joinGame(){
//		System.out.println("Enterss join Game");
		findGame();
		ChatMessage msg;
		//is valid usename
		//send username and gamename
		String[] usernames;
	        // allocates memory for 10 integers
		usernames = new String[4];
	           
	        // initialize first element
		usernames[0] ="playerUserName0" ;usernames[1] ="playerUserName1" ;usernames[2] ="playerUserName2" ;usernames[3] ="playerUserName3" ;
		int counter = 0;String userName = "";

		while(true){
//			System.out.println("Enterss while loop");
			if(counter>0){
				System.out.println("username "+userName +" exists in game. chose another");
			}
			userName = usernames[counter];
			msg = new ChatMessage(userName, gameName);
			msg.setType(constants.joinGame);
			sendMessage(msg);
			try {msg = (ChatMessage) ois.readObject();} catch (ClassNotFoundException | IOException e) {e.printStackTrace();}
			counter++;	
//			System.out.println("message is"+msg.getMessage());
			if(msg.getMessage().equals(constants.usernameUnique)){
//				System.out.println("Enterss break condition");
				break;
			}
		}
	
		
		
		
		
		
	}
	private void findGame(){
		while(true){
			gameName = "gameName1";
			ChatMessage cm = new ChatMessage(userName, gameName);
			cm.setType(constants.findGame);
			sendMessage(cm);
			try {cm = (ChatMessage) ois.readObject();} catch (ClassNotFoundException | IOException e) {e.printStackTrace();}
			if(cm.getMessage().equals("true")){			break;				}
		}
		
	}
	private void gameName(){
		userName = "PlayerClient";
		String gameName = "gameName1";
		ChatMessage msg = new ChatMessage(userName, gameName);
		msg.setType(constants.uniqueGameName);
		sendMessage(msg);
		
		try { 
//			System.out.println("Object type is"+(ois.readObject()));
			msg = (ChatMessage) ois.readObject();
			if(msg.getMessage().equals("true")){
//				break;
				System.out.println("unique game name chosen as:"+ msg.getUsername());
			}
			else{
				System.out.println("game name already chosen");
			}
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("fails trying to read the message");
		}
	}
	private void newGame(){
		//determine number of players
		int maxPlayers = 3;
		gameName();//determine game name
		userName = "playerUserName0";
		if(userName.trim().length()==0){}//break;
		//send username and number of players
		ChatMessage msg = new ChatMessage(userName, Integer.toString(maxPlayers));
		msg.setType(constants.usernamePlayers);
		sendMessage(msg);
		while(maxPlayers>0){
			System.out.println("Waiting for " + maxPlayers +" players to join");
			try {
				msg = (ChatMessage) ois.readObject();
				String newPlayerUsername = msg.getUsername();
				System.out.println( newPlayerUsername +" just joined");maxPlayers--;
				
			} catch (ClassNotFoundException | IOException e) {e.printStackTrace();}
			
		}
		
		
		
//Chat messaging		
		
//		System.out.println("Please enter a unique name for your game. \n");
//thisa is just general chat messaging code. Once reaches here cant read anything else	
		while(true) {
			Scanner scan = new Scanner(System.in);
			String line = scan.nextLine();
			ChatMessage cm = new ChatMessage("Jeff", line);
			try {
				oos.writeObject(cm);
				oos.flush();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			//pw.println("Donald: " + line);
			//pw.flush();
		}
	
	}
	private void connect(){
		String hostname = "localhost";
		int port = 6789;
try {
	System.out.println("Trying to connect to " + hostname + ":" + port);
	Socket s = new Socket(hostname, port);
	System.out.println("Connected to " + hostname + ":" + port);
	//br = new BufferedReader(new InputStreamReader(s.getInputStream()));
	//pw = new PrintWriter(s.getOutputStream());
	ois = new ObjectInputStream(s.getInputStream());
	oos = new ObjectOutputStream(s.getOutputStream());
	
	Scanner scan = new Scanner(System.in);
	
	
} catch (IOException ioe) {
	System.out.println("ioe in playerClient constructor: " + ioe.getMessage());
}
	}
	public void run() {
		try {
			while(true) {
				//String line = br.readLine();
				//System.out.println(line);
				ChatMessage cm = (ChatMessage)ois.readObject();
				System.out.println(cm.getUsername() + ": " + cm.getMessage());
			}
		} catch (IOException ioe) {
			System.out.println("ioe in playerClient.run(): " + ioe.getMessage());
		} catch (ClassNotFoundException cnfe) {
			System.out.println("cnfe: " + cnfe.getMessage());
		}
	}
	private void sendMessage(ChatMessage cm) {
//		pw.println(message);
//		pw.flush();
		try {
			oos.writeObject(cm);
			oos.flush();
		} catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
	}
	public static void main(String [] args) {
		playerClient cc = new playerClient();
	}
}
