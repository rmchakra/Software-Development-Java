package gamePackage;

import java.util.Vector;
import networking.*;

public class Game {
	String gameName = "no game name";
	ServerThread creator;
	int awaitingPlayers = 0;
	Vector<ServerThread> players;

	public ServerThread getCreator() {
		return creator;
	}
	public void setCreator(ServerThread creator) {
		this.creator = creator;
	}
	public int getAwaitingPlayers() {
		return awaitingPlayers;
	}
	public void setAwaitingPlayers(int awaitingPlayers) {
		this.awaitingPlayers = awaitingPlayers;
	}
	public Vector<ServerThread> getPlayers() {
		return players;
	}
	public void setPlayers(Vector<ServerThread> players) {
		this.players = players;
	}
	public void addPlayer(ServerThread player) {
		players.add(player);
	}

	public Game(String gameName, ServerThread creator, int awaitingPlayers) {
		super();
		this.gameName = gameName;
		this.awaitingPlayers = awaitingPlayers;
		this.creator= creator;
		players = new Vector<ServerThread>();
		addPlayer(creator);
		
	}

	public int getawaitingPlayers() {
		return awaitingPlayers;
	}

	public void setawaitingPlayers(int awaitingPlayers) {
		this.awaitingPlayers = awaitingPlayers;
	}


	public String getGameName() {
		return gameName;
	}

	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
}
