package part1;
import java.util.Scanner;
import java.util.Vector;
import java.util.concurrent.ThreadLocalRandom;

import part1.*;


public class war1 {
	Scanner scan;
	war1(){
		scan = new Scanner(System.in);
		Vector<Card> deck = new Vector<Card>();
		
		int player1=100, player2 =100;Card p1Card = null; Card p2Card = null;
		boolean turnPlayer1= true;
		
			deck = Card.create_deck();
			println("Player 1 bet:");
			int bet=101;
			try{
					bet = scan.nextInt();					
					if(bet>0 && bet< 101){
						println("Player 2 agrees?:");scan.nextLine();
						String choice = scan.nextLine();
						if(choice.equalsIgnoreCase("yes")){
							int randomNum1 = ThreadLocalRandom.current().nextInt(0,  deck.size()), randomNum2 = ThreadLocalRandom.current().nextInt(0,  deck.size()-1);
							p1Card = deck.get(randomNum1);//replace 1 with randomNum if working
							deck.removeElementAt(randomNum1);
							
							p2Card = deck.get(randomNum2);
							deck.removeElementAt(randomNum2);
							println("Player 1 Card :"+p1Card.getName());
							println("Player 2 Card :"+p2Card.getName());
							while(p1Card.getValue()== p2Card.getValue()){
								randomNum1 = ThreadLocalRandom.current().nextInt(0,  deck.size());
								randomNum2 = ThreadLocalRandom.current().nextInt(0,  deck.size()-1);
								
								println("Ready to continue?");
								choice = scan.nextLine();
								if(choice.equalsIgnoreCase("yes")){
									p1Card = deck.get(randomNum1);//replace 1 with randomNum if working
									deck.removeElementAt(randomNum1);
									p2Card = deck.get(randomNum2);
									deck.removeElementAt(randomNum2);
									println("Player 1 Card :"+p1Card.getName());
									println("Player 2 Card :"+p2Card.getName());
								}else{
									break;
								}
								
							}
							if(p1Card.getValue() > p2Card.getValue()){println("Player 1 wins $:"+bet);println("Player 2 loses $:"+bet);}
							else if(p2Card.getValue() > p1Card.getValue())
							{println("Player 2 wins$ :"+bet);println("Player 1 loses $:"+bet);}
							
					}														
				}
				else{println("Incorrect bet amount. Enter between 1 and 100");}
				
			}catch(Exception e){
				println("bet is not a number");
			}			
		println("Thank you for playing war.");
	}
	
	
	
	public static void main(String [] args) {
		war1 war = new war1();	
	}
	public static void println(String s){
		System.out.println(s);
	}
	public void print(String s){
		System.out.print(s);
	}
}
