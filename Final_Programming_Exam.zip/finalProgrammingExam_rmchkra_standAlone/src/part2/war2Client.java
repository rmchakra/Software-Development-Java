package part2;
import part1.Card;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class war2Client {
	private ObjectInputStream ois;
	private ObjectOutputStream oos;
	Scanner scan;
	Card card;
	war2Client(int port){
		connect(6789);
	}
	private void connect(int port){
//		while(true){
			String hostname = "localhost";	
			scan = new Scanner(System.in);
			try {		
				GameMessage cm = new GameMessage("message from client");
				System.out.println("Trying to connect to " + hostname + ":" + port);
				Socket s = new Socket(hostname, port);
				System.out.println("Connected to " + hostname + ":" + port);
				//br = new BufferedReader(new InputStreamReader(s.getInputStream()));
				//pw = new PrintWriter(s.getOutputStream());
				ois = new ObjectInputStream(s.getInputStream());
				oos = new ObjectOutputStream(s.getOutputStream());
				cm = readMessage();print(cm.getMessage());//player 1 bet
				println("accept bet?"); String accept = scan.nextLine();
				sendMessage(cm);
				try {
					card = (Card)ois.readObject();
					
				} catch (ClassNotFoundException | IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				cm = readMessage();//
				} catch (IOException ioe) {
					System.out.println("Invalid Ip address/ hostname combo");
				}
			catch (Exception ioe) {
				System.out.println("Invalid Ip address/ hostname combo");
			}
			
//		}
		
	}
	public static void main(String [] args){					
				war2Client s = new war2Client(6789);						
	}
	public static void println(String s){
		System.out.println(s);
	}
	public void print(String s){
		System.out.print(s);}
	public void sendMessage(GameMessage cm) {
//		pw.println(message);
//		pw.flush();
		try {
			oos.writeObject(cm);
			oos.flush();
		} catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
	}
	public GameMessage readMessage() {
//		pw.println(message);
//		pw.flush();
		GameMessage msg =null;
		try {
			msg = (GameMessage)ois.readObject();
			
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return  msg;
		
	}
}
