package part2;

import java.io.Serializable;

public class GameMessage implements Serializable {
	public static final long serialVersionUID = 1;
	private String username;
	private String message;
	private String type = "no type";
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public GameMessage(String username, String message) {
		this.username = username;
		this.message = message;
	}
	public GameMessage(String message) {
		this.message = message;
	}
	public String getUsername() {
		return username;
	}
	public String getMessage() {
		return message;
	}
}
