package part2;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.util.Vector;
import java.util.concurrent.ThreadLocalRandom;

import part1.Card;


public class war2Server {
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	Scanner scan;
	GameMessage cm;
	war2Server(int port){
		try {
			ServerSocket ss = new ServerSocket(port);
			while(true){
				try{
					Socket s = ss.accept();
					oos = new ObjectOutputStream(s.getOutputStream());
					ois = new ObjectInputStream(s.getInputStream());
					
					scan = new Scanner(System.in);
					Vector<Card> deck = new Vector<Card>();
					
					int player1=100, player2 =100;Card p1Card = null; Card p2Card = null;
					println("Player 1 bet:");
					int bet=101;
					try{bet = scan.nextInt();	
					cm.setMessage("Player 1 bet:"+bet); sendMessage(cm);
					cm = readMessage();
					println("Player 2 agrees?:"+ cm.getMessage());
					if(cm.getMessage().equalsIgnoreCase("yes")){
						int randomNum1 = ThreadLocalRandom.current().nextInt(0,  deck.size()), randomNum2 = ThreadLocalRandom.current().nextInt(0,  deck.size()-1);
						p1Card = deck.get(randomNum1);//replace 1 with randomNum if working
						deck.removeElementAt(randomNum1);
						
						p2Card = deck.get(randomNum2);
						deck.removeElementAt(randomNum2);
						println("Player 1 Card :"+p1Card.getName());
						println("Player 2 Card :"+p2Card.getName());
						try {
							oos.writeObject(p2Card);
							oos.flush();
						} catch (IOException ioe) {
							System.out.println("ioe: " + ioe.getMessage());
						}
						
					}
					
						
					}catch (Exception e){
						
					}
							
					
					
					
					
					
					
					
					
					GameMessage cm = readMessage();
					print(cm.getMessage());
					cm.setMessage("message from server");
					sendMessage(cm);
					readMessage();
				}
				catch(Exception e){
					//round has ended
				}
				
			}
				
			
			
		
		
		} catch (IOException e) {e.printStackTrace(); print("try a new port current port in use");}
	}
	public void sendMessage(GameMessage cm) {
//		pw.println(message);
//		pw.flush();
		try {
			oos.writeObject(cm);
			oos.flush();
		} catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
	}
	public GameMessage readMessage() {
//		pw.println(message);
//		pw.flush();
		GameMessage msg =null;
		try {
			msg = (GameMessage)ois.readObject();
			
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return  msg;
		
	}
	public static void main(String [] args){
		
				war2Server s = new war2Server(6789);
			
		
	}
	public void println(String s){
		System.out.println(s);
	}
	public void print(String s){
		System.out.print(s);}
}
