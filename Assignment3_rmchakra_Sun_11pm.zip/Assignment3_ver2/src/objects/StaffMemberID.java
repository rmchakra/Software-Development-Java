package objects;

public class StaffMemberID {
	private Integer staffMemberID;

	public Integer getID() {
		return staffMemberID;
	}
}
