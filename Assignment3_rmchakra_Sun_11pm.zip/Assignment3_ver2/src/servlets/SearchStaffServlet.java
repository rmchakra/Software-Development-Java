package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import parsing.StringConstants;
import objects.*;

/**
 * Servlet implementation class clearStaffServlet
 */
@WebServlet("/SearchStaffServlet")
public class SearchStaffServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchStaffServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		String staffMemberQuery = request.getParameter("staffMemberQuery");
//		actually searching for the name
		DataContainer data = (DataContainer) request.getSession().getAttribute(StringConstants.DATA);
		School school = data.getSchools().get(0);
		Department dept = school.getDepartments().get(0);
		Course course = dept.getCourses().get(0);
		
		String fullName = "dummyName";
		for(StaffMember mem : course.getStaffMembers())
		{
			if(staffMemberQuery.equalsIgnoreCase(mem.getName().getFirstName()) || (staffMemberQuery.equalsIgnoreCase(mem.getName().getLastName())) ||(staffMemberQuery.equalsIgnoreCase(mem.getName().getFirstName()+" "+mem.getName().getLastName())) )
			{
				fullName = mem.getName().getFirstName()+mem.getName().getLastName();
			}
		}
		request.getSession().setAttribute("lastSearched",fullName);
		PrintWriter pw = response.getWriter();
		pw.print(fullName);
		pw.flush();
		pw.close();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
