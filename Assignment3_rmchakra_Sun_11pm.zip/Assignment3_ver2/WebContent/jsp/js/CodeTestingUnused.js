
function searchStaffFunc(){
	//is actually clear staff
//				document.getElementById("button result").innerHTML = document.searchStaff.staffMemberQuery.value;
				document.getElementById("button result").innerHTML = "search staff";
//				System.out.println("search staff");
				/* return false; */
//				document.body.style.backgroundColor = "#EEEEEE";
//				$("*").css("backgroundColor", "#EEEEEE");
				var xhttp = new XMLHttpRequest();
				xhttp.open("GET", "../clearStaffServlet", true);
				xhttp.send(); 
				
				
				xhttp.onreadystatechange = function() {
					  if (this.readyState == 4 && this.status == 200) {
					    
						  var ls = 	xhttp.responseText;	
							
							
							
							var x = document.getElementsByClassName(ls);
							console.log("items returned:"+x.length);
							
						    var i;
						    for (i = 0; i < x.length; i++) {
						        x[i].style.backgroundColor = "#EEEEEE";
						    }
					  }
					};
		
				
				
}
		
function clearStaff(){
	//is actually search staff
	searchStaffFunc();
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "../SearchStaffServlet?staffMemberQuery="+document.searchStaff.staffMemberQuery.value, true);
	xhttp.send(); 
	xhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
//		    document.getElementById("demo").innerHTML = this.responseText;
		    document.getElementById("button result").innerHTML = xhttp.responseText;
			var fullName = xhttp.responseText;
//			get element by id will only return 1, but, I need to somehow get all
			 var x = document.getElementsByClassName(fullName);
			    var i;
			    for (i = 0; i < x.length; i++) {
			        x[i].style.backgroundColor = "lightblue";
			    }
			}
		};
}