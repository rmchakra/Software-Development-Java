//Document instructions
//There must be at least one School
//Each School must have at least one Department
//Each Department must have at least one Course
//Each Course must have at least one Staff Member (of any type) and at least one Meeting (of any type)
//All attributes of a School, Department, and Course should be non-null
//Each Meeting should have non-null values for the type and section attributes
//Each Staff Member should have non-null values for the type, id, and name attributes
// check that fname and lname are not null


//RIGHT NOW ASSUMING WILL GO TO A SCHOOL. PROG WILL CRASH IF NOT OR WRONG INPUT


import java.util.ArrayList;
import java.util.Scanner;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonIOException;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.google.gson.stream.MalformedJsonException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.IOException;
//importing my packages
import object_storage.*;
public class Main {
	public static void main(String[] args) {
		ArrayList <School> schoolsArray = new ArrayList<School>();
		while(!readJason(schoolsArray)){
			schoolsArray = new ArrayList<School>();
		};//reading in jason tree model	
		exec(schoolsArray);//executing program	
			
		
		
		
	}
	public static void exec(ArrayList<School> schoolsArray)

	{
		//menu 1
		Scanner in = new Scanner(System.in);
		String choice;
		String opQues = "What would you like to do?";
		while(true)
		{
//MENU 1			
			System.out.println("1) Display schools \n2) Exit \n"+opQues);
			choice = in.nextLine();
			if(invalidInput(choice)){continue;}
			
			if(choice.equals("2")){exit();return;}//exit
			else if(choice.equals("1"))//display schools
			{
				boolean menu2ContinueFlag = false;
				while(true)
				{

					System.out.println("Schools");
					for(int i = 0 ; i< schoolsArray.size();i++)
					{
	//MENU 2
						System.out.println((i+1)+") "+schoolsArray.get(i).name);
					}
					System.out.println((schoolsArray.size()+1)+") Go to main menu");
					System.out.println((schoolsArray.size()+2)+") Exit");
					System.out.println(opQues);
					choice = in.nextLine();
					if(invalidInput(choice)){continue;}
					if(Integer.parseInt(choice)>(schoolsArray.size()+2))
					{
						System.out.println("That is not a valid option (out of range of options).");
						continue;
					}

					if(choice.equals(Integer.toString(schoolsArray.size()+1)))
					{break;}
					
					
					else if(choice.equals(Integer.toString(schoolsArray.size()+2)))
					{exit();return;}
					
					School school = schoolsArray.get(Integer.parseInt(choice)-1);
//					if(choice.compareTo())
					while(true)
					{
						System.out.println("Departments");
						for(int i = 0; i<school.departments.size();i++)
						{
							Department department = school.departments.get(i);
		//MENU 3					
							System.out.println((i+1)+") "+department.longName+" (" + department.prefix + ")");
						}
						System.out.println((school.departments.size()+1)+") Go to Schools menu");
						System.out.println((school.departments.size()+2)+") Exit");
						System.out.println(opQues);
						choice = in.nextLine();
						if(choice.equals(Integer.toString(school.departments.size()+2)))//exit
						{exit();return;}
						else if(choice.equals(Integer.toString(school.departments.size()+1)))//return to previous menu
						{break;}
						if(invalidInput(choice)){continue;}
						if(Integer.parseInt(choice)>(school.departments.size()+2))
						{
							System.out.println("That is not a valid option (out of range of options).");
							continue;
						}
						//assuming it has to be one of the right choices after that henc enot in a block
						Department department = school.departments.get(Integer.parseInt(choice)-1);
						//MENU 4	
						while(true)
						{
							System.out.println(department.prefix+" Courses");
							//department prefix course:number term year
							
							for(int i = 0; i<department.courses.size();i++)
							{
								Course course = department.courses.get(i);
								System.out.println((i+1)+") "+department.prefix+ " "+ course.number+ " "+ course.term+ " "+course.year);
							}
							System.out.println((department.courses.size()+1)+") Go to Departments menu");
							System.out.println((department.courses.size()+2)+") Exit");
							System.out.println(opQues);
							choice = in.nextLine();
							if(choice.equals(Integer.toString(department.courses.size()+2)))//exit
							{exit();return;}
							if(choice.equals(Integer.toString(department.courses.size()+1)))//return to previous menu
							{break;}
							if(invalidInput(choice)){continue;}
							if(Integer.parseInt(choice)>(department.courses.size()+2))//repeat same menu
							{
								System.out.println("That is not a valid option (out of range of options).");
								continue;
							}			
							
							Course course = department.courses.get(Integer.parseInt(choice)-1);
			//MENU 5=no need for choice checking ionly else		
							
							while(true)
							{
								
								System.out.println(department.prefix+ " "+ course.number+ " "+ course.term+ " "+course.year);
								System.out.println("1) View course staff"+'\n'+"2) View meeting information");
								System.out.println("3) Go to CSCI Courses menu"+'\n'+"4) Exit");
								choice = in.nextLine();
								
								if(choice.equals("4"))//exit
								{exit();return;}
								else if(choice.equals("3"))// return to previous menu: Courses menu
								{break;}			
					//menu 8			
								else if(choice.equals("1"))
								{
									
									while(true)
									{
										System.out.println("1) View Instructors \n 2) View TAs \n 3) View CPs \n 4) View Graders");
										System.out.println("5) Go to "+department.prefix+ " "+ course.number+ " "+ course.term+ " "+course.year);
										System.out.println("6) Exit");
										choice = in.nextLine();
										if(invalidInput(choice))
										{continue;}
										if(choice.equals("6"))//exit
										{exit();return;}
										if(choice.equals("5"))//return to previous menu
										{break;}
										
										if(choice.equals("1") ||choice.equals("2")||choice.equals("3")||choice.equals("4"))
										{
												StaffMember staffMember = new StaffMember();
												
												if(choice.equals("1"))
												{
													course.staffMembers = course.INstaffMembers;
												}
												else if(choice.equals("2"))
												{
													course.staffMembers=course.TAstaffMembers;
												}
												else if(choice.equals("3"))
												{
													course.staffMembers=course.CPstaffMembers;
												}
												else
												{
													course.staffMembers=course.GRstaffMembers;
												}
												System.out.println(department.prefix+ " "+ course.number+ " "+ course.term+ " "+course.year);
												
												if(course.staffMembers!=null)
												{
													for(int i =0; i<course.staffMembers.size(); i++)
													{
														staffMember = course.staffMembers.get(i);
														System.out.println((i+1)+") View: "+staffMember.type);
//														staffMember = course.staffMembers.get(Integer.parseInt(choice)-1);
														System.out.println(staffMember.type);
														System.out.println("Name: "+ staffMember.name.fName+" "+ staffMember.name.lName);
														System.out.println("Email: "+ staffMember.email);
														System.out.println("Image: "+ staffMember.image);
														System.out.println("Phone: "+ staffMember.phone);
														System.out.println("Office: "+ staffMember.office);
														System.out.print("Office Hours:");
														OfficeHour officeHour = new OfficeHour();
														for(int i1 = 0 ; i1<staffMember.officeHours.size(); i1++)
														{
															officeHour = staffMember.officeHours.get(i1);
															System.out.print(officeHour.day+" "+officeHour.timing.start+"-"+officeHour.timing.end+",");
														}
														System.out.println();
														
													}
												}
										}
										else
										{
											System.out.println("That is not a valid option.");
										}
										
									}
								}
								// MENU 6
								
								else if(choice.equals("2"))
								{
									while(true)
									{
										Meeting meeting = new Meeting();
										System.out.println(department.prefix+ " "+ course.number+ " "+ course.term+ " "+course.year);						
										System.out.println("Meeting Information");
										for (int i = 0; i < course.meetings.size(); i++) 
										{
											meeting = course.meetings.get(i);
											System.out.println((i+1)+") "+meeting.type);		
										}
										System.out.println((course.meetings.size()+1)+") "+department.prefix+ " "+ course.number+ " "+ course.term+ " "+course.year+" menu");
										System.out.println((course.meetings.size()+2)+") Exit");
										choice = in.nextLine();
										
										if(choice.equals(Integer.toString(course.meetings.size()+2)))//exit
										{exit();return;}
										if(choice.equals(Integer.toString(course.meetings.size()+1)))//exit
										{break;}
										if(invalidInput(choice)){continue;}
										if(Integer.parseInt(choice)>(course.meetings.size()+2))//repeat same menu
										{
											System.out.println("That is not a valid option (out of range of options).");
											continue;
										}
										
										
										
										meeting = course.meetings.get(Integer.parseInt(choice)-1);
					//MENU 7					
										System.out.println(department.prefix+ " "+ course.number+ " "+ course.term+ " "+course.year);//CSCI 201 Summer 2017
										System.out.println(meeting.type+" Meeting Information");
										System.out.println("Section: "+ meeting.section);
										System.out.println("Room:"+meeting.room);
										
										//looping over meeting periods
										MeetingPeriod meetingPeriod = new MeetingPeriod(); 
										System.out.print("Meetings: ");
										for(int i = 0; i<meeting.meetingPeriods.size() ; i++)
										{
											meetingPeriod = meeting.meetingPeriods.get(i);
											System.out.print(meetingPeriod.day+" "+meetingPeriod.timing.start+"-"+meetingPeriod.timing.end+",");
										}
										System.out.println();
										System.out.print("Assistants: ");
										for(int i = 0; i<meeting.assistants.size() ; i++)
										{
											Assistant assistant = meeting.assistants.get(i);
											System.out.print(assistant.name);
										}								
										System.out.println("");
										//meetings
										//assistants
									}
								}
								else
								{
									System.out.println("That is not a valid option");
								}		
							}
						}
						
					
					}
				}
			
	
			}
			else
			{
				System.out.println("That is not a valid option else");
			}
		}
		
		
	}
	public static boolean invalidInput(String input)
	{
		String msg ="That is not a valid option.";
		if(input.length()==0)
		{
			System.out.println(msg);
			return true;
		}
		for(int i = 0; i<input.length(); i++)//checking if input is an integer
		{
			if(!Character.isDigit(input.charAt(i)))
			{
				System.out.println(msg);
				return true;
			}
//			
		}
		if(input.equals("0"))
		{return true;}
		return false;
	}
 	public static boolean wrongFileName(String fileName)
	{
		boolean invalid;
		
		BufferedReader br;	
		try {
			br = new BufferedReader(new FileReader(fileName));
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("That file could not be found.");
		}
		
		
		if(fileName=="" )//check errors here
		{
			System.out.println("That file is not a well-formed JSON file.");
			return true;
		}
		
		return false;
	}
//BELOW THIS READING IN THE INFO	
	public static boolean readJason(ArrayList<School> schoolsArray)
	{
		//reading in the filename as user input
		Scanner in = new Scanner(System.in);
		String fileName = "";
		do{
			System.out.println("What is the name of the input file?");
			fileName = in.nextLine();
			
		}while(wrongFileName(fileName));
//--------------------------------------------------------------------------------------------------------------------------	
//--------------------------------------------------------------------------------------------------------------------------	
//--------------------------------------------------------------------------------------------------------------------------	
		
		
		FileReader reader;
		JsonElement jElement;//rootNode
		JsonObject jObject;
		JsonArray jArray;
		JsonParser parser = new JsonParser(); 
		try {
			
//READING FILE
			reader = new FileReader(new File(fileName));
			
//ACCESSING ROOT NODE	
			
			jElement = parser.parse(reader);	
			
//accessing root obj which contains 1 key-value pair
			jObject = jElement.getAsJsonObject();
			//JsonElement schols = rootObj.getAsJsonObject("schools");//remember this will not work. trying toa ccept an array as an element			
			
			if(jObject==null){return false;}//empty file
			
//getting array of schools
			jArray = jObject.getAsJsonArray("schools");			
//atleast 1 school
			if(jArray.size()==0){return false;}
			
			
			
			
//ITERATING SCHOOLS
			for(int i = 0; i<jArray.size(); i++)
		    {
				School school = new School();
//			    accessing 1 school object which contains all the key value pairs
				jObject = jArray.get(i).getAsJsonObject();
				
				
				
				jElement  = jObject.get("name"); //getting the school name
				if(jElement==null){return false;}//All attributes of a School should be non null
				school.name=jElement.getAsString();
//ACCESSING DEPARTMENTS
				JsonArray departmentsArray = jObject.getAsJsonArray("departments");
				if(departmentsArray==null){return false;}
//atleast 1 department
				if(departmentsArray.size()==0){return false;}
				for(int j = 0; j<departmentsArray.size(); j++)
			    {
					Department department = new Department();
					jObject = departmentsArray.get(j).getAsJsonObject();
					jElement = jObject.get("longName");
					if(jElement==null){return false;}//All attributes of a department should be non null
					department.longName=jElement.getAsString();//longname
					
					
					
					
					jElement = jObject.get("prefix");
					if(jElement==null){return false;}//All attributes of a department should be non null
					department.prefix=jElement.getAsString();//prefix
//ACCESSING COURSE					
					
					JsonArray courseArray = jObject.getAsJsonArray("courses");
					//atleast 1 course
					if(courseArray==null){return false;}
					
					if(courseArray.size()==0){return false;}
					for(int k = 0; k< courseArray.size(); k++)
				    {
						Course course = new Course();
						jObject = courseArray.get(k).getAsJsonObject();
						jElement = jObject.get("number"); 
						if(jElement==null){return false;}//All attributes of a course should be non null
						course.number=jElement.getAsInt();//course number
						
						jElement = jObject.get("term");
						if(jElement==null){return false;}//All attributes of a course should be non null
						course.term=jElement.getAsString();//course term
						
						jElement = jObject.get("year");
						if(jElement==null){return false;}//All attributes of a course should be non null
						course.year = jElement.getAsInt();//course year
//ACCESSING STAFF MEMBERS						
						JsonArray staffMemberArray = jObject.getAsJsonArray("staffMembers");
						if(staffMemberArray==null){return false;}
						if(staffMemberArray.size()==0){return false;}
						for(int l = 0; l<  staffMemberArray.size(); l++)
						{
							StaffMember staffMember = new StaffMember();
							JsonObject jObjectStaff = staffMemberArray.get(l).getAsJsonObject();
							jElement = jObjectStaff.get("type");
							if(jElement==null){return false;}//type not null
							staffMember.type = jElement.getAsString();//staffMember type
							
							jElement = jObjectStaff.get("id");
							if(jElement==null){return false;}//id not null
							staffMember.id = jElement.getAsInt();//staffMember type
							
							
//ACCESSING NAME			
							JsonObject jObjectName= jObjectStaff.getAsJsonObject("name");
							if(jObjectName==null){return false;}//type not null
							jElement = jObjectName.get("fname");
							if(jElement==null){staffMember.name.fName="";}//type not null
							else{staffMember.name.fName=jElement.getAsString();}//fname
							
							jElement = jObjectName.get("lname");
							if(jElement==null){staffMember.name.lName="";}//type not null
							else{staffMember.name.lName=jElement.getAsString();}//lname
							
							
							jElement = jObjectStaff.get("email");
							if(jElement!=null)
							{staffMember.email = jElement.getAsString();}//email
							
							jElement = jObjectStaff.get("image");
							if(jElement!=null)
							{staffMember.image = jElement.getAsString();}//image
							
							jElement = jObjectStaff.get("phone");
							if(jElement!=null)
							{staffMember.phone = jElement.getAsString();}//phone
							jElement = jObjectStaff.get("office");
							if(jElement!=null)
							{staffMember.office = jElement.getAsString();}//office		
							
//ACCESSING OFFICE HOURS
							
							JsonArray officeHoursArray = jObjectStaff.getAsJsonArray("officeHours");
							if(officeHoursArray != null)
							{
								for(int m = 0; m<  officeHoursArray.size(); m++)
								{
									OfficeHour officeHour = new OfficeHour();
									JsonObject jObjectOfficeHour= officeHoursArray.get(m).getAsJsonObject();
									
									jElement = jObjectOfficeHour.get("day");
									officeHour.day = jElement.getAsString();//office hour day					
	//ACCESSING TIME	
									Timing timing = new Timing();
									JsonObject jObjectTime= jObjectOfficeHour.getAsJsonObject("time");
									if(jObjectTime!=null)
									{
										jElement = jObjectTime.get("start");
										timing.start = jElement.getAsString();//office hour time start
										
										jElement = jObjectTime.get("end");
										timing.end = jElement.getAsString();//office hour time start
										
										officeHour.timing = timing;	
									}
									else
									{
										officeHour.timing = null;
									}
									
									staffMember.officeHours.add(officeHour);
								}
							}
							String type = staffMember.type;
							if(type.equals("instructor"))
							{
								course.INstaffMembers.add(staffMember);
							}
							else if(type.equalsIgnoreCase("ta"))
							{
								course.TAstaffMembers.add(staffMember);
							}
							else if(type.equalsIgnoreCase("cp"))
							{
								course.CPstaffMembers.add(staffMember);
							}
							else if(type.equalsIgnoreCase("grader"))
							{
								course.GRstaffMembers.add(staffMember);
							}
							course.staffMembers.add(staffMember);
						}
//ACCESSING MEETINGS
						JsonArray meetingArray = jObject.getAsJsonArray("meetings");
						if(meetingArray==null){return false;}
						if(meetingArray.size()==0){return false;}
						
						for(int l = 0; l<  meetingArray.size(); l++)
						{
							Meeting meeting = new Meeting();
							JsonObject jObjectMeeting = meetingArray.get(l).getAsJsonObject();
							
							jElement = jObjectMeeting.get("type");
							if(jElement==null){return false;}//meeting type non null
							
							meeting.type=jElement.getAsString();//meeting type

							jElement = jObjectMeeting.get("section");
							if(jElement==null){return false;}//meeting section non null
							
							meeting.section=jElement.getAsString();//meeting section

							jElement = jObjectMeeting.get("room");
							if(!(jElement==null))
							{meeting.room=jElement.getAsString();//meeting section
							}
							else
							{meeting.room ="unknown room";
							}
							
							JsonArray assistantArray = jObjectMeeting.getAsJsonArray("assistants");
							if(assistantArray != null)
							{
								for(int m = 0; m<  assistantArray.size(); m++)
								{
									Assistant assistant = new Assistant();

									JsonObject jObjectAssistant = assistantArray.get(m).getAsJsonObject();
									jElement = jObjectAssistant.get("staffMemberID");
									assistant.staffMemberID = jElement.getAsInt();//staffMember type
									
									
									for(int n = 0; n<  staffMemberArray.size(); n++)
									{
										Name name = new Name();
										JsonObject jObjectStaff = staffMemberArray.get(n).getAsJsonObject();
										jElement = jObjectStaff.get("id");
										if(jElement.getAsString().equals(Integer.toString(assistant.staffMemberID)))
										{
											
											JsonObject jObjectName= jObjectStaff.getAsJsonObject("name");
											jElement = jObjectName.get("fname");
											name.fName=jElement.getAsString();//fname
											
											jElement = jObjectName.get("lname");
											name.lName=jElement.getAsString();//lname
											
											
											if(jElement!=null)
											{
												assistant.name = name.fName+" "+name.lName;	
											}
										}
									}
									meeting.assistants.add(assistant);	
								}
							}
							JsonArray meetingPeriodArray = jObjectMeeting.getAsJsonArray("meetingPeriods");
							if(meetingPeriodArray!=null)
							{
								for(int m = 0; m<  meetingPeriodArray.size(); m++)
								{
									MeetingPeriod meetingPeriod = new MeetingPeriod();
									JsonObject jObjectMeetingPeriod = meetingPeriodArray.get(m).getAsJsonObject();
									jElement = jObjectMeetingPeriod.get("day");
									meetingPeriod.day = jElement.getAsString();//day							
									
									Timing timing = new Timing();
									JsonObject timeObject = jObjectMeetingPeriod.getAsJsonObject("time");
									jElement = timeObject.get("start");
									timing .start = jElement.getAsString();//start
									
									jElement = timeObject.get("end");
									timing .end = jElement.getAsString();//start
									
									meetingPeriod.timing = timing;
									meeting.meetingPeriods.add(meetingPeriod);
								}
							}
							
							
							
							course.meetings.add(meeting);
							
						}
						
						
						
						
						
						
						
					department.courses.add(course);	
				    }
					
				school.departments.add(department);	
			    }
				

			schoolsArray.add(school);	
		    }
				
		} catch (FileNotFoundException e) {//code will never be reached since already checking for that
			System.out.println("That file could not be found.");
			return false;
			
		}
		catch (JsonParseException e){
			System.out.println("file cannot be parsed");
			return false;
		}
		catch (Exception e){//since if appropriate variable is not int then will throw this automatically also fordata types
			System.out.println("file cannot be parsed");
			return false;
		}

//		in.close();	
		return true;
	}
	public static void exit()
	{
		System.out.println("Thank you for using my program!");
	}
}



