package object_storage;
import java.util.*;
public class Employee
{
   private Integer id;
   private String firstName;
   private String lastName;
   private ArrayList<String> roles;
   private custom_datatype custom;
    
   public Employee(){      
   }
    
   public Employee(Integer id, String firstName, String lastName, Date birthDate){
      this.id = id;
      this.firstName = firstName;
      this.lastName = lastName;
   }
    
   public Integer getId()
   {
      return id;
   }
   public void setId(Integer id)
   {
      this.id = id;
   }
   public String getFirstName()
   {
      return firstName;
   }
   public void setFirstName(String firstName)
   {
      this.firstName = firstName;
   }
   public String getLastName()
   {
      return lastName;
   }
   public void setLastName(String lastName)
   {
      this.lastName = lastName;
   }
   public ArrayList<String> getRoles()
   {
      return roles;
   }
   public void setRoles(ArrayList<String> roles)
   {
      this.roles = roles;
   }
    
   @Override
   public String toString()
   {
	   if(custom == null)
	   {
		   System.out.println("custom is null");
		   
	   }
	   
	   return "Employee [id=" + id + ", firstName=" + firstName + ", " +
            "lastName=" + lastName + ", roles=" + roles + "]";
//	   +"custom longname ="+ custom.getLongName()
   }

public custom_datatype getCustom() {
	return custom;
}

public void setCustom(custom_datatype custom) {
	this.custom = custom;
}
}