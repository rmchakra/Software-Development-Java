package object_storage;

import java.util.ArrayList;

public class Course {
	public int number;
	public String term;
	public int year;
	public ArrayList<StaffMember> staffMembers;
	public ArrayList<Meeting> meetings;

	public Course() {
		staffMembers = new ArrayList<StaffMember>();
		meetings = new ArrayList<Meeting>();
		
	}
	public Course(int number, String term, int year, ArrayList<StaffMember> staffMembers,
			ArrayList<Meeting> meetings) {
		this.number = number;
		this.term = term;
		this.year = year;
		this.staffMembers = staffMembers;
		this.meetings = meetings;
	}
	
}
