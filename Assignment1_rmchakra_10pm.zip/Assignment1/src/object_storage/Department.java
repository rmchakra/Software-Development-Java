package object_storage;

import java.util.ArrayList;

public class Department {

	public String longName;
	public String prefix;
	public ArrayList<Course> courses;
	public Department() {
		courses = new ArrayList<Course> ();
	}
	public Department(String longName, String prefix, ArrayList<Course> courses) {
		
		this.longName = longName;
		this.prefix = prefix;
		this.courses = courses;
	}

}
