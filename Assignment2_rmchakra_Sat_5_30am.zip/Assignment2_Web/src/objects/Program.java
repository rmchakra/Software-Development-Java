package objects;

import java.util.ArrayList;
import java.util.List;

public class Program {
	List <File> files;

	public Program() {
		files = new ArrayList();
	}

	public List<File> getFiles() {
		return files;
	}

	public void setFiles(List<File> files) {
		this.files = files;
	}
	

}
