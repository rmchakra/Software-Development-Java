package servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import objects.DataContainer;
import parsing.Parser;
import parsing.StringConstants;
import driver.JDBCDriver;

/**
 * Servlet implementation class ChooseFile
 */
@WebServlet("/ChooseFile")
@MultipartConfig
public class ChooseFile extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 Part filePart = request.getPart(StringConstants.FILE); 
		 DataContainer data;
		 String name = request.getParameter("name");
		 String pw = request.getParameter("pw");
		 String ip = request.getParameter("ip");
		 request.getSession().setAttribute(StringConstants.DESIGN, (String)request.getParameter(StringConstants.DESIGN));
		 String[] ssls = null;
		 ssls = request.getParameterValues("ssl");
		 boolean ssl;
		 if(ssls != null){
			 ssl = true;
		 }else{
			 ssl = false;
		 }
//		 System.out.println("SSL value is" + ssl);
		 InputStreamReader fileContent = new InputStreamReader(filePart.getInputStream());
		 BufferedReader br = new BufferedReader(fileContent);
		 data = new Parser(br).getData();
		 JDBCDriver.connect(ip,name, pw, ssl);
		 if(data!= null){
			 //if uploading a file then save to the database.
			 JDBCDriver.clearTables();	
			 br.close();
			 fileContent.close();
			 JDBCDriver.writeToDatabase(data);
		 }
		 else{
			 //if not uploading a file then read from database
			 data = new DataContainer();
			 JDBCDriver.readFromDatabase(data);
//			 System.out.println("Data is null");
		 }
		 data.organize();
		 request.getSession().setAttribute(StringConstants.DATA, data);
		 println("School name usc =" + data.getSchools().get(0).getName());
		 println("NOW CRASH SINCE NO COURSE");
			
		 request.getSession().setAttribute(StringConstants.COURSE, data.getSchools().get(0).getDepartments().get(0).getCourses().get(0));
		
		 
		 
		 request.getSession().setMaxInactiveInterval(600);
		 response.sendRedirect("jsp/"+StringConstants.HOME_JSP);
	}
	private void println(String string) {
		System.out.println(string);		
	}
	private void print(String string) {
		System.out.print(string);		
	}

}
