package objects;

import java.util.ArrayList;
import java.util.List;

public class Program {
	private List<File> files;

	public Program() {
		super();
		files =new ArrayList<File>();
	}

	public List<File> getFiles() {
		return files;
	}
	public void addFile(File f) {
		files.add(f);
	}
}
