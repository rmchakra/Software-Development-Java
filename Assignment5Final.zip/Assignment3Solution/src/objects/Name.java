package objects;

public class Name {
	private String fname;
	private String lname;

	public Name(){
		
	}
	public Name(String fname, String lname) {
		super();
		this.fname = fname;
		this.lname = lname;
	}
	public String getFirstName() {
		return fname;
	}

	public String getLastName() {
		return lname;
	}
}
