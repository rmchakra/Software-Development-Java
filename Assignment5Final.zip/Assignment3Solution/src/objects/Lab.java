package objects;

import java.util.*;

//lab extends GeneralObject because it has the exact same member variables as deliverables
public class Lab extends GeneralObject{
	public Lab(Integer number, String title, String url) {
		super(number, title, url);
		files = new ArrayList<File>();
		// TODO Auto-generated constructor stub
	}
	public Lab() {
		files = new ArrayList<File>();
		// TODO Auto-generated constructor stub
	}
	private List<File> files;
	public List<File> getFiles(){
		return files;
	}
	public void addFile(File file){
		files.add(file);
	}
}
