package objects;

public class StaffMemberID {
	private Integer staffMemberID;

	public Integer getID() {
		return staffMemberID;
	}

	public Integer getStaffMemberID() {
		return staffMemberID;
	}

	public void setStaffMemberID(Integer staffMemberID) {
		this.staffMemberID = staffMemberID;
	}
}
