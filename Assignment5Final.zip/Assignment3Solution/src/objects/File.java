package objects;

//file inherits from GeneralObject because labs have the exact same member variables
public class File extends GeneralObject{

	public File() {
		super();
		// TODO Auto-generated constructor stub
	}

	public File(Integer number, String title, String url) {
		super(number, title, url);
		// TODO Auto-generated constructor stub
	}

}
