package objects;

import java.util.ArrayList;
import java.util.List;

public class Assignment extends GeneralAssignment {
	
	private String url;
	private List<File> gradingCriteriaFiles;
	private List<File> solutionFiles;
	private List<Deliverable> deliverables;
	// already has var : files since inherits from general assignment,
	
	public String getUrl() {
		return url;
	}

	public Assignment() {
		super();
		gradingCriteriaFiles = new ArrayList<File> ();
		solutionFiles = new ArrayList<File> ();
		deliverables = new ArrayList<Deliverable>();
	}
	public void addgradingCriteriaFile(File f){
		gradingCriteriaFiles.add(f);
	}
	public void addsolutionFile(File f){
		solutionFiles.add(f);
	}

	public List<Deliverable> getDeliverables() {
		return deliverables;
	}

	public List<File> getGradingCriteriaFiles() {
		return gradingCriteriaFiles;
	}

	public List<File> getSolutionFiles() {
		return solutionFiles;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public void setGradingCriteriaFiles(List<File> gradingCriteriaFiles) {
		this.gradingCriteriaFiles = gradingCriteriaFiles;
	}

	public void setSolutionFiles(List<File> solutionFiles) {
		this.solutionFiles = solutionFiles;
	}

	public void setDeliverables(List<Deliverable> deliverables) {
		this.deliverables = deliverables;
	}

}
