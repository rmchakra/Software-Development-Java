package objects;

import java.util.ArrayList;
import java.util.List;

public class Topic extends GeneralObject {
	private String chapter;
	private List<Program> programs;

	public Topic() {
		super();
		 programs = new ArrayList<Program>();
		 chapter = "null";
	}

	public String getChapter() {
		return chapter;
	}

	public List<Program> getPrograms() {
		return programs;
	}

	public void setChapter(String chapter) {
		this.chapter = chapter;
	}

	public void setPrograms(List<Program> programs) {
		this.programs = programs;
	}
	public void addProgram(Program program) {
		programs.add(program);
	}
}
