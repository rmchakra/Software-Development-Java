package driver;
import objects.*;
import objects.Time;
import parsing.StringConstants;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// all methods are static since unnecessary to generate object to use the methods each time
public class JDBCDriver {
	private static Connection conn = null;
	private static ResultSet rs = null;
	private static PreparedStatement ps = null;
	private static String ip;
	private static String username;
	private static String password;
	private static boolean ssl;
		
	private static void test(DataContainer data){
		Course c = data.getSchools().get(0).getDepartments().get(0).getCourses().get(0);
		Schedule s = c.getSchedule();
		//checking OH
//		List<StaffMember> StaffMembers = data.getSchools().get(0).getDepartments().get(0).getCourses().get(0).getStaffMembers();
//		println("id and start similar to OH table");
//		println("staff member count : " + StaffMembers.size());
//		for(StaffMember m : StaffMembers){
//
//			println("OH count : " + m.getOfficeHours().size());
//			for(TimePeriod oh : m.getOfficeHours()){
//				println("id = "+ m.getID()+ "start ="+ oh.getTime().getStart());
//			}
//			
//		}
		
		//checking labs
//		List<Week> weeks = s.getWeeks();
//		for(Week w : weeks){
//			print("week:"+w.getWeek());
////			println("week number:"+w.getWeek()+"lab count: " + w.getLabs().size());
//			for(Lab l : w.getLabs()){
//				print(" lab:"+ l.getNumber() );
////				println("lab number = "+ l.getNumber());
//				for(File f: l.getFiles()){
//					print(" number:"+ f.getNumber()+" title:"+f.getTitle());
//					
//				}
//				println(" ");
//			}
//			println(" ");
//		}
		
		
		
	}
	
	//all write functions
	public static void writeToDatabase(DataContainer data){
		//create the database from filled data obj
		Course course = writeCourse(data.getSchools().get(0));
		writeStaffMembers(course.getStaffMembers());
		writeMeetings(course.getMeetings());
		writeTextBooks(course.getSchedule().getTextbooks());
		writeLabs(course.getSchedule().getWeeks());
		writeLectures(course.getSchedule().getWeeks());
		writeAssignments(course.getAssignments());
		
		
		
		
		
		close();	
		
	}
	private static Course writeCourse(School school){
		Department dept = school.getDepartments().get(0);
		Course course = dept.getCourses().get(0);
		//schoolName, schoolImage, departmentLongName, departmentPrefix, number, title, term, year, syllabus
		try {
			ps = conn.prepareStatement("insert into "+StringConstants.TABLECOURSE+" ("+StringConstants.SCHOOLNAME+","+ StringConstants.SCHOOLIMAGE+","+ StringConstants.DEPARTMENTLONGNAME+","+ StringConstants.DEPARTMENTPREFIX+","+ StringConstants.NUMBER+","+ StringConstants.TITLE+","+ StringConstants.UNITS+","+ StringConstants.TERM+","+ StringConstants.YEAR+","+ StringConstants.SYLLABUS+") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");			
			ps.setString(1, school.getName());
			ps.setString(2, school.getImage());
			ps.setString(3, dept.getLongName());
			ps.setString(4, dept.getPrefix());
			ps.setString(5, course.getNumber());
			ps.setString(6, course.getTitle());
			ps.setInt(7, course.getUnits());
			ps.setString(8, course.getTerm());
			ps.setInt(9, course.getYear());
			ps.setString(10, course.getSyllabus().getUrl());			
			ps.executeUpdate();//add the course table
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return course;
	}
	private static void writeStaffMembers(List<StaffMember> staffMembers){
		//type, id, fname, lname, email, image, phone, office
		
		for(StaffMember staffMember : staffMembers){
			try {
				ps = conn.prepareStatement("insert into "+ StringConstants.TABLESTAFFMEMBERS+" ("+StringConstants.TYPE+","+ StringConstants.ID+","+ StringConstants.FNAME+","+ StringConstants.LNAME+","+ StringConstants.EMAIL+","+ StringConstants.IMAGE+","+ StringConstants.PHONE+","+ StringConstants.OFFICE+") VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
				ps.setString(1, staffMember.getJobType());
				ps.setInt(2, staffMember.getID() );
				ps.setString(3, staffMember.getName().getFirstName() );
				ps.setString(4, staffMember.getName().getLastName() );
				ps.setString(5,staffMember.getEmail() );
				ps.setString(6, staffMember.getImage() );
				ps.setString(7, staffMember.getPhone() );
				ps.setString(8, staffMember.getOffice() );			
				ps.executeUpdate();
				writeOH(staffMember);
		
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
	}
	private static void writeOH(StaffMember staffMember){
		List<TimePeriod> officeHours = staffMember.getOH();
		//		ohID (not inserted),  staffId, day, start, end
		for(TimePeriod oh : officeHours){
			try {
				ps = conn.prepareStatement("insert into "+ StringConstants.TABLEOH+" ("+StringConstants.STAFFID+","+ StringConstants.DAY+","+ StringConstants.START+","+ StringConstants.END+" ) VALUES (?, ?, ?, ?)");
				ps.setInt(1, staffMember.getID() );
				ps.setString(2, oh.getDay());		
				ps.setString(3, oh.getTime().getStartTime());
				ps.setString(4, oh.getTime().getEndTime() );
				ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	}
	private static void writeMeetings(List<Meeting> meetings){
		for(Meeting meeting : meetings){
			try {
				//type, section, room
				ps = conn.prepareStatement("insert into "+ StringConstants.TABLEMEETING+" ("+StringConstants.TYPE+","+ StringConstants.SECTION+","+ StringConstants.ROOM+" ) VALUES (?, ?, ?)");
				ps.setString(1,meeting.getType() );	
				ps.setString(2, meeting.getSection());
				ps.setString(3, meeting.getRoom() );
				ps.executeUpdate();
				writeMeetingPeriods(meeting);
				writeAssistants(meeting);
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	private static void writeMeetingPeriods(Meeting meeting){
		for(TimePeriod meetingPeriod : meeting.getMeetingPeriods()){
			try {
				//idmeetingPeriod (unused), day, start, end, section
				ps = conn.prepareStatement("insert into "+ StringConstants.TABLEMEETINGPERIOD+" ("+StringConstants.DAY+","+ StringConstants.START+","+ StringConstants.END+","+ StringConstants.SECTION+" ) VALUES (?, ?, ?, ?)");
				ps.setString(1,meetingPeriod.getDay() );
				ps.setString(2, meetingPeriod.getTime().getStartTime() );	
				ps.setString(3, meetingPeriod.getTime().getEndTime());
				ps.setString(4, meeting.getSection());
				ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	private static void writeAssistants(Meeting meeting){
		for(StaffMemberID assistant : meeting.getAssistants()){
			try {
				//idmeetingPeriod (unused), day, start, end, section
				ps = conn.prepareStatement("insert into "+ StringConstants.TABLEASSISTANTS+" ("+ StringConstants.SECTION+","+ StringConstants.ID+" ) VALUES (?, ?)");
				ps.setString(1,meeting.getSection());
				ps.setInt(2, assistant.getID());	
				ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	private static void writeTextBooks(List <Textbook> books){
		for(Textbook book : books){
			try {
//				textbooks : number, author, title, publisher, year, isbn
				ps = conn.prepareStatement("insert into "+ StringConstants.TABLETEXBOOKS+" ("+ StringConstants.NUMBER+","+ StringConstants.AUTHOR+","+ StringConstants.TITLE+","+ StringConstants.PUBLISHER+","+ StringConstants.YEAR+","+ StringConstants.ISBN+" ) VALUES (?, ?, ?, ?, ?, ?)");
				ps.setInt(1,book.getNumber());
				ps.setString(2,book.getAuthor());
				ps.setString(3,book.getTitle());
				ps.setString(4,book.getPublisher());
				ps.setString(5,book.getYear());
				ps.setString(6,book.getIsbn());
				ps.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	private static void writeLabs(List <Week> weeks){//also writes weeks table
//		int labid = 1;
		for(Week week : weeks){
			try {
				ps = conn.prepareStatement("insert into weeks (week) VALUES (?)");
				ps.setInt(1,week.getWeek());					
				ps.executeUpdate();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			for(Lab lab : week.getLabs()){
				try {
//					labs :idlabs (auto), week, number, title, url
					
					
					ps = conn.prepareStatement("insert into "+ StringConstants.TABLELABS+" ("+ StringConstants.WEEK+","+ StringConstants.NUMBER+","+ StringConstants.TITLE+","+ StringConstants.URL+" ) VALUES (?, ?, ?, ?)");
					
					
					ps.setInt(1,week.getWeek());					
					ps.setInt(2,lab.getNumber());
					ps.setString(3,lab.getTitle());
					ps.setString(4,lab.getUrl());
					ps.executeUpdate();
					for(File file : lab.getFiles()){
//						labFiles : idlabFiles (AUTO), week, lab, number, title, url
						ps = conn.prepareStatement("insert into "+ StringConstants.TABLELABFILES+" ("+ StringConstants.WEEK+","+ StringConstants.LAB+","+ StringConstants.NUMBER+","+ StringConstants.TITLE+","+ StringConstants.URL+" ) VALUES (?, ?, ?, ?, ?)");
									
						ps.setInt(1,week.getWeek());					
						ps.setInt(2,lab.getNumber());
						ps.setInt(3,file.getNumber());
						ps.setString(4,file.getTitle());
						ps.setString(5,file.getUrl());
						ps.executeUpdate();
						
					}
				} catch (SQLException e) {e.printStackTrace();}
			}
			
		}
	}
	private static void writeLectures(List <Week> weeks){
//		int labid = 1;
		for(Week week : weeks){		
			for(Lecture lecture : week.getLectures()){
				try {
//					lectures: idlectures (auto),WEEK,  number, day, date
					ps = conn.prepareStatement("insert into "+ StringConstants.TABLELECTURES+" ("+ StringConstants.WEEK+","+StringConstants.NUMBER+","+ StringConstants.DAY+","+ StringConstants.DATE+" ) VALUES (?, ?, ?, ?)");
					
					
					ps.setInt(1,week.getWeek());					
					ps.setInt(2,lecture.getNumber());
					ps.setString(3,lecture.getDay());
					ps.setString(4,lecture.getDate());
					ps.executeUpdate();
					for(Topic topic : lecture.getTopics()){
//						topics:idtopics (auto), week, lecture, number, title, url, chapter
						ps = conn.prepareStatement("insert into "+ StringConstants.TABLETOPICS+" ("+ StringConstants.WEEK+","+ StringConstants.LECTURE+","+ StringConstants.NUMBER+","+ StringConstants.TITLE+","+ StringConstants.URL+","+ StringConstants.CHAPTER+" ) VALUES (?, ?, ?, ?, ?, ?)");				
						ps.setInt(1,week.getWeek());					
						ps.setInt(2,lecture.getNumber());
						ps.setInt(3,topic.getNumber());
						ps.setString(4,topic.getTitle());
						ps.setString(5,topic.getUrl());
						ps.setString(6,topic.getChapter());
						ps.executeUpdate();
						int progCounter = 1;
						for(Program program: topic.getPrograms()){
							for(File file : program.getFiles()){
								//programFiles :idnew_table (auto), week, lecture, topic, program, number, title, url
								ps = conn.prepareStatement("insert into "+ StringConstants.TABLEPROGRAMFILES+" ("+ StringConstants.WEEK+","+ StringConstants.LECTURE+","+ StringConstants.TOPIC+","+ StringConstants.PROGRAM+","+ StringConstants.NUMBER+","+ StringConstants.TITLE+","+ StringConstants.URL+" ) VALUES (?, ?, ?, ?, ?, ?, ?)");				
								ps.setInt(1,week.getWeek());					
								ps.setInt(2,lecture.getNumber());
								ps.setInt(3,topic.getNumber());							
								ps.setInt(4,progCounter);
								ps.setInt(5,file.getNumber());
								ps.setString(6,file.getTitle());
								ps.setString(7,file.getUrl());
								ps.executeUpdate();
								
							}
							progCounter++;
						}
					}
				} catch (SQLException e) {e.printStackTrace();}
			}
			
		}
	}
	private static void writeAssignments(List <Assignment> assignments){//also writes weeks table
//		int labid = 1;
		for(Assignment assignment : assignments){
			try {//number, assignedDate, dueDate, title, url, gradePercentage
				ps = conn.prepareStatement("insert into "+ StringConstants.TABLEASSIGNMENTS+" ("+ StringConstants.NUMBER+","+StringConstants.ASSIGNEDDATE+","+ StringConstants.DUEDATE+","+ StringConstants.TITLE+","+ StringConstants.URL+","+StringConstants.GRADEPERCENTAGE+" ) VALUES (?, ?, ?, ?, ?, ?)");
				ps.setString(1,assignment.getNumber());
				ps.setString(2,assignment.getAssignedDate());
				ps.setString(3,assignment.getDueDate());
				ps.setString(4,assignment.getTitle());
				ps.setString(5,assignment.getUrl());
				ps.setString(6,assignment.getGradePercentage());
				ps.executeUpdate();
				//3 file types files, frading criteria, solutions
				for(File f : assignment.getSolutionFiles()){
//					Assignment Files : idlabFiles (AUTO), number (assignment number), title, url, type
					ps = conn.prepareStatement("insert into "+ StringConstants.TABLEASSIGNMENTFILES+" ("+ StringConstants.NUMBER+","+ StringConstants.TITLE+","+ StringConstants.URL+","+ StringConstants.TYPE+" ) VALUES (?, ?, ?, ?)");								
					ps.setString(1,assignment.getNumber());
					ps.setString(2,assignment.getTitle());
					ps.setString(3,assignment.getUrl());
					ps.setString(4,StringConstants.SOLUTION);
					ps.executeUpdate();
				}
				for(File f : assignment.getGradingCriteriaFiles()){
//					Assignment Files : idlabFiles (AUTO), number (assignment number), title, url, type
					ps = conn.prepareStatement("insert into "+ StringConstants.TABLEASSIGNMENTFILES+" ("+ StringConstants.NUMBER+","+ StringConstants.TITLE+","+ StringConstants.URL+","+ StringConstants.TYPE+" ) VALUES (?, ?, ?, ?)");								
					ps.setString(1,assignment.getNumber());
					ps.setString(2,assignment.getTitle());
					ps.setString(3,assignment.getUrl());
					ps.setString(4,StringConstants.GRADINGCRITERIA);
					ps.executeUpdate();
				}
				for(File f : assignment.getFiles()){
//					Assignment Files : idlabFiles (AUTO), number (assignment number), title, url, type
					ps = conn.prepareStatement("insert into "+ StringConstants.TABLEASSIGNMENTFILES+" ("+ StringConstants.NUMBER+","+ StringConstants.TITLE+","+ StringConstants.URL+","+ StringConstants.TYPE+" ) VALUES (?, ?, ?, ?)");								
					ps.setString(1,assignment.getNumber());
					ps.setString(2,assignment.getTitle());
					ps.setString(3,assignment.getUrl());
					ps.setString(4,StringConstants.FILE);
					ps.executeUpdate();
				}
				
				
				
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			
		}
	}
	
	
	//all read functions
	public static void readFromDatabase(DataContainer data){
		readCourse(data);
		readStaffMembers (data);
		readMeetings (data);
		readTextBooks (data);
		Course c = returnCourse(data);			
		addCourse(data, readWeeks(c));
		c = returnCourse(data);	
		addCourse(data, readAssignments(c));
		
		test(data);
		
		//		read from database into data variable
		//do not do new DataContainer else wont reference same data obj
		
		//reading values
//		ps = conn.prepareStatement("SELECT UserID FROM course WHERE Username =?");
//		ps.setString(1, usr);
//		rs = ps.executeQuery();
//		
//		if(rs.next()){
//			println("enters if next");
//			return rs.getInt("UserID");
//		}
		

//		ps = conn.prepareStatement("SELECT "+StringConstants.SCHOOLIMAGE +" FROM "+ StringConstants.TABLECOURSE +" WHERE "+ StringConstants.SYLLABUS + " = ?");
//		ps.setString(1,course.getSyllabus().getUrl());
//		rs = ps.executeQuery();
////		
////		print();
//		if(rs.next()){
//			println("enters if next");
//			print("Should be TRUE =");
//			println(Boolean.toString(school.getImage().equals(rs.getString(StringConstants.SCHOOLIMAGE))));
//		}
	}
	private static void readCourse(DataContainer data){
		School s = new School();
		try {
//			ps = conn.prepareStatement("SELECT "+StringConstants.SCHOOLIMAGE +" FROM "+ StringConstants.TABLECOURSE);
			ps = conn.prepareStatement("SELECT * FROM "+ StringConstants.TABLECOURSE);
			rs = ps.executeQuery();
			if(rs.next()){
				//course table inquiry
				s.setImage(rs.getString(StringConstants.SCHOOLIMAGE));
				println("School image url =" + s.getImage());
				s.setName(rs.getString(StringConstants.SCHOOLNAME));
				println("School name usc =" + s.getName());
				Department d = new Department();
				d.setLongName(rs.getString(StringConstants.DEPARTMENTLONGNAME));
				d.setPrefix(rs.getString(StringConstants.DEPARTMENTPREFIX));
				Course c = new Course();
				c.setNumber(rs.getString(StringConstants.NUMBER));
				c.setTitle(rs.getString(StringConstants.TITLE));
				c.setUnits(rs.getInt(StringConstants.UNITS));
				c.setTerm(rs.getString(StringConstants.TERM));
				c.setYear(rs.getInt(StringConstants.YEAR));
				Syllabus syllabus = new Syllabus();
				syllabus.setUrl(rs.getString(StringConstants.SYLLABUS));				
				c.setSyllabus(syllabus);
				d.addCourse(c);
				s.addDepartment(d);				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		data.getSchools().add(s);
	}
	private static void readStaffMembers (DataContainer data){
		Course c = data.getSchools().get(0).getDepartments().get(0).getCourses().get(0);
		
		//reading so no list exists
//		List<StaffMember> staffMembers = c.getStaffMembers();
		try {
//			ps = conn.prepareStatement("SELECT "+StringConstants.SCHOOLIMAGE +" FROM "+ StringConstants.TABLECOURSE);
			ps = conn.prepareStatement("SELECT * FROM "+ StringConstants.TABLESTAFFMEMBERS);
			rs = ps.executeQuery();
			while(rs.next()){//each next moves it to new row with first one to first row
				StaffMember staffMember = new StaffMember();
				staffMember.setType(rs.getString(StringConstants.TYPE));
				staffMember.setId(rs.getInt(StringConstants.ID));
				Name name = new Name(rs.getString(StringConstants.FNAME), rs.getString(StringConstants.LNAME));				
				staffMember.setName(name);
				staffMember.setEmail(rs.getString(StringConstants.EMAIL));
				staffMember.setImage(rs.getString(StringConstants.IMAGE));
				staffMember.setPhone(rs.getString(StringConstants.PHONE));
				staffMember.setOffice(rs.getString(StringConstants.OFFICE));
				readOh (staffMember);
				//office hours function
				
				c.addStaffMember(staffMember);
			}
			
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		
		data.getSchools().get(0).getDepartments().get(0).addCourse(c);
	}
	private static void readOh (StaffMember staffMember){
		//fk is id
		try {
			PreparedStatement ps1 = conn.prepareStatement("SELECT * FROM "+ StringConstants.TABLEOH +" WHERE "+ StringConstants.STAFFID+" ="+staffMember.getId());
			ResultSet rs1 = ps1.executeQuery();
			while(rs1.next()){
				//each next moves it to new row with first one to first row
				TimePeriod officeHour  = new TimePeriod();
				Time time = new Time();
				time.setStart(rs1.getString(StringConstants.START));
				time.setEnd(rs1.getString(StringConstants.END));
				officeHour.setDay(rs1.getString(StringConstants.DAY));
				officeHour.setTime(time);
				staffMember.addOfficeHour(officeHour);			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	private static void readMeetings (DataContainer data){
		Course c = data.getSchools().get(0).getDepartments().get(0).getCourses().get(0);
		
		//reading so no list exists
//		List<StaffMember> staffMembers = c.getStaffMembers();
		try {
//			ps = conn.prepareStatement("SELECT "+StringConstants.SCHOOLIMAGE +" FROM "+ StringConstants.TABLECOURSE);
			ps = conn.prepareStatement("SELECT * FROM "+ StringConstants.TABLEMEETING);
			rs = ps.executeQuery();
			while(rs.next()){//each next moves it to new row with first one to first row
				Meeting meeting = new Meeting();
				
				meeting.setType(rs.getString(StringConstants.TYPE));
				meeting.setSection(rs.getString(StringConstants.SECTION));
				meeting.setRoom(rs.getString(StringConstants.ROOM));
				
				readMeetingPeriods (meeting);
				readAssistants(meeting);
				
				c.addMeeting(meeting);
			}
			
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		
		data.getSchools().get(0).getDepartments().get(0).addCourse(c);
	}
	private static void readMeetingPeriods (Meeting meeting){
		//fk is id
		try {
			String section = meeting.getSection();
			PreparedStatement ps1 = conn.prepareStatement("SELECT * FROM "+ StringConstants.TABLEMEETINGPERIOD +" WHERE "+ StringConstants.SECTION +" ='"+section+"'");
			ResultSet rs1 = ps1.executeQuery();
			while(rs1.next()){
				//each next moves it to new row with first one to first row
				TimePeriod meetingPeriod  = new TimePeriod();
				Time time = new Time();
				time.setStart(rs1.getString(StringConstants.START));
				time.setEnd(rs1.getString(StringConstants.END));
				meetingPeriod.setDay(rs1.getString(StringConstants.DAY));
				meetingPeriod.setTime(time);
				meeting.addMeetingPeriod(meetingPeriod);		
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}
	private static void readAssistants(Meeting meeting){
			try {
				// section, id
				PreparedStatement ps1 = conn.prepareStatement("SELECT * FROM "+ StringConstants.TABLEASSISTANTS+" WHERE "+ StringConstants.SECTION +" ='"+meeting.getSection()+"'");
				ResultSet rs1 = ps1.executeQuery();
				while(rs1.next()){
					StaffMemberID assistant = new StaffMemberID();
					assistant.setStaffMemberID(rs1.getInt(StringConstants.ID));
					meeting.addAssistant(assistant);
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
	private static void readTextBooks (DataContainer data){
		Course c = data.getSchools().get(0).getDepartments().get(0).getCourses().get(0);
		Schedule schedule = new Schedule();
		//reading so no list exists
//		List<StaffMember> staffMembers = c.getStaffMembers();
		try {
//			ps = conn.prepareStatement("SELECT "+StringConstants.SCHOOLIMAGE +" FROM "+ StringConstants.TABLECOURSE);
			ps = conn.prepareStatement("SELECT * FROM "+ StringConstants.TABLETEXBOOKS);
			rs = ps.executeQuery();
			while(rs.next()){//each next moves it to new row with first one to first row
				Textbook book = new Textbook();
//				textbooks : number, author, title, publisher, year, isbn
				book.setNumber(rs.getInt(StringConstants.NUMBER));
				book.setAuthor(rs.getString(StringConstants.AUTHOR));
				book.setTitle(rs.getString(StringConstants.TITLE));
				book.setPublisher(rs.getString(StringConstants.PUBLISHER));
				book.setYear(rs.getString(StringConstants.YEAR));
				book.setIsbn(rs.getString(StringConstants.ISBN));
				schedule.addTextbook(book);
			}
			
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		c.setSchedule(schedule);
		data.getSchools().get(0).getDepartments().get(0).addCourse(c);
	}
	private static Course readWeeks (Course c){
		Schedule schedule = c.getSchedule();
		
		//reading so no list exists
//		List<StaffMember> staffMembers = c.getStaffMembers();
		try {
			//add labs - create the weeks, then, lectures modifies weeks
			PreparedStatement ps2 = conn.prepareStatement("SELECT * FROM weeks");
			ResultSet rs2 = ps2.executeQuery();
			while(rs2.next()){
				Week week = new Week();
				week.setWeek(rs2.getInt("week"));
				//reading labs
				ps = conn.prepareStatement("SELECT * FROM "+ StringConstants.TABLELABS +" WHERE week ="+rs2.getInt("week"));
				rs = ps.executeQuery();
				while(rs.next()){//while there are labs for this week
					Lab lab = new Lab();
					lab.setNumber(rs.getInt(StringConstants.NUMBER));
					lab.setTitle(rs.getString(StringConstants.TITLE));
					lab.setUrl(rs.getString(StringConstants.URL));
					
					PreparedStatement ps1 = conn.prepareStatement("SELECT * FROM "+ StringConstants.TABLELABFILES + " WHERE week=" +week.getWeek() + " AND lab=" + lab.getNumber());
					//where week and lab match
					ResultSet rs1 = ps1.executeQuery();
					while(rs1.next()){//lab files
						
						File file = new File(rs1.getInt(StringConstants.NUMBER), rs1.getString(StringConstants.TITLE), rs1.getString(StringConstants.URL));				
						lab.addFile(file);
					}				
					week.addLab(lab);
				}
				//reading lectures
				ps = conn.prepareStatement("SELECT * FROM "+ StringConstants.TABLELECTURES +" WHERE week ="+rs2.getInt("week"));
				rs = ps.executeQuery();
				while(rs.next()){//LECTURES for this week
					Lecture lecture = new Lecture();
					lecture.setNumber(rs.getInt(StringConstants.NUMBER));
					lecture.setDay(rs.getString(StringConstants.DAY));
					lecture.setDate(rs.getString(StringConstants.DATE));
					
					//topics : idtopics (auto), week, lecture, number, title, url, chapter
					PreparedStatement ps1 = conn.prepareStatement("SELECT * FROM "+ StringConstants.TABLETOPICS + " WHERE week=" +week.getWeek() + " AND lecture=" + lecture.getNumber());
					//where week and lab match
					ResultSet rs1 = ps1.executeQuery();//DONT USE RS2
					while(rs1.next()){//TOPICs
						Topic topic = new Topic();
						topic.setNumber(rs1.getInt(StringConstants.NUMBER));
						topic.setTitle(rs1.getString(StringConstants.TITLE));
						topic.setUrl(rs1.getString(StringConstants.URL));
						String chapter = rs1.getString(StringConstants.CHAPTER);
						println("chapter returned:" + chapter);
						if(!chapter.equals("null")){//there is a chapter
							topic.setChapter(chapter);
						}
						
						//reading in the programs for each topic
						//idnew_table (AUTO), week, lecture, topic, program, number, title, url
						ps = conn.prepareStatement("SELECT * FROM "+ StringConstants.TABLEPROGRAMFILES +" WHERE week ="+rs2.getInt("week")+ " AND lecture=" + lecture.getNumber()+ " AND topic=" + topic.getNumber());
						ResultSet rs3 = ps.executeQuery();//gives all the program files : DONT USE RS2
						int prevProgram = -1;
						while(rs3.next()){//programs
							int progNum = rs3.getInt(StringConstants.PROGRAM);
							File file = new File(rs3.getInt(StringConstants.NUMBER), rs3.getString(StringConstants.TITLE), rs3.getString(StringConstants.URL));								
							if(topic.getPrograms().size() < progNum){//is a new program progNum!=prevProgram
//								prevProgram = progNum;
								Program program = new Program();
								program.addFile(file);
								topic.addProgram(program);						
							}else{
								topic.getPrograms().get(progNum-1).addFile(file);
							}
						}
							
						
//						File file = new File(rs1.getInt(StringConstants.NUMBER), rs1.getString(StringConstants.TITLE), rs1.getString(StringConstants.URL));				
						lecture.addTopic(topic);
					}
					
					week.addLecture(lecture);
				}				
				schedule.addWeek(week);
			}
		}catch (SQLException e) {e.printStackTrace();}	
		c.setSchedule(schedule);
		return c;
	}
	
	//this is garbage now
	private static Course readAssignments (Course c){
		
//		List<StaffMember> staffMembers = c.getStaffMembers();
		try {
//			ps = conn.prepareStatement("SELECT "+StringConstants.SCHOOLIMAGE +" FROM "+ StringConstants.TABLECOURSE);
			ps = conn.prepareStatement("SELECT * FROM "+ StringConstants.TABLEASSIGNMENTS);
			rs = ps.executeQuery();
			while(rs.next()){//each assignment
				Assignment assignment = new Assignment();
//				assignments : number, assignedDate, dueDate, title, url
				assignment.setNumber(rs.getString(StringConstants.NUMBER));
				assignment.setAssignedDate(rs.getString(StringConstants.ASSIGNEDDATE));
				assignment.setDueDate(rs.getString(StringConstants.DUEDATE));
				assignment.setTitle(rs.getString(StringConstants.TITLE));
				assignment.setUrl(rs.getString(StringConstants.URL));
				assignment.setGradePercentage(rs.getString(StringConstants.GRADEPERCENTAGE));
				//ADDING files
				ps = conn.prepareStatement("SELECT * FROM "+ StringConstants.TABLEASSIGNMENTFILES +" WHERE "+ StringConstants.NUMBER +" ='"+assignment.getNumber()+"'");
				ResultSet rs1 = ps.executeQuery();
				while(rs1.next()){
					String number = rs1.getString(StringConstants.NUMBER);
					if(number.contains("Final Project")){//skips final project
						continue;
					}
					File file = new File(rs1.getInt(StringConstants.NUMBER), rs1.getString(StringConstants.TITLE), rs1.getString(StringConstants.URL));				
					
					String type = rs1.getString(StringConstants.TYPE);
					//each assignment
					if(type.contains(StringConstants.FILE)){
						assignment.addFile(file);
					}else if(type.contains(StringConstants.GRADINGCRITERIA)){
						assignment.addgradingCriteriaFile(file);
					}else{//solution
						assignment.addsolutionFile(file);
					}
				}
				c.addAssignment(assignment);
			}
			
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return c;
	}
	
	public static void connect(String ipPar, String usernamePar, String passwordPar, boolean sslPar){
		ip = ipPar;
		username = usernamePar;
		password = passwordPar;
		ssl = sslPar;
		
//		ip = "localhost";
//		username = "root";
//		password = "betaLeData1";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://"+ip+"/rmchakra_201_site?user="+username+"&password="+password+"&useSSL="+Boolean.toString(ssl));		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void close(){
		try{
			if (rs!=null){
				rs.close();
				rs = null;
			}
			if(conn != null){
				conn.close();
				conn = null;
			}
			if(ps != null ){
				ps = null;
			}
		}catch(SQLException sqle){
			System.out.println("connection close error");
			sqle.printStackTrace();
		}
	}
	public static void clearTables(){
		try {
			Statement st = conn.createStatement();
			st.executeUpdate("SET FOREIGN_KEY_CHECKS = 0");
			st.executeUpdate("TRUNCATE "+ StringConstants.TABLEOH);
			st.executeUpdate("TRUNCATE "+ StringConstants.TABLECOURSE);
			st.executeUpdate("TRUNCATE "+ StringConstants.TABLESTAFFMEMBERS );
			st.executeUpdate("TRUNCATE "+ StringConstants.TABLEMEETING );
			st.executeUpdate("TRUNCATE "+ StringConstants.TABLEMEETINGPERIOD );
			st.executeUpdate("TRUNCATE "+ StringConstants.TABLEASSISTANTS );
			st.executeUpdate("TRUNCATE "+ StringConstants.TABLELABS );
			st.executeUpdate("TRUNCATE "+ StringConstants.TABLELABFILES );
			st.executeUpdate("TRUNCATE "+ StringConstants.TABLETEXBOOKS );
			st.executeUpdate("TRUNCATE "+ StringConstants.TABLEWEEKS);
			st.executeUpdate("TRUNCATE "+ StringConstants.TABLELECTURES);
			st.executeUpdate("TRUNCATE "+ StringConstants.TABLEPROGRAMFILES);
			st.executeUpdate("TRUNCATE "+ StringConstants.TABLETOPICS);	
			st.executeUpdate("TRUNCATE "+ StringConstants.TABLEASSIGNMENTS);
			st.executeUpdate("SET FOREIGN_KEY_CHECKS = 1");
			
			} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static boolean validate(String usr, String pwd){
//		connect();
		try {
			ps = conn.prepareStatement("SELECT password FROM User WHERE username=?");
			ps.setString(1, usr);
			rs = ps.executeQuery();
			System.out.println(rs);
			if(rs.next()){
				if(pwd.equals(rs.getString("password")) ){
					return true;
				}
			}
		} catch (SQLException e) {
			System.out.println("SQLException in function \"validate\"");
			e.printStackTrace();
		}finally{
			close();
		}
		return false;		
	}
	public static void increment(String usr, String page){
//		connect();
		try{
			ps = conn.prepareStatement("SELECT userID FROM User WHERE username =?");
			ps.setString(1, usr);
			rs = ps.executeQuery();
			int userID = -1;
			if(rs.next()){
				userID = rs.getInt("userID");
			}
			rs.close();
			ps = conn.prepareStatement("SELECT pageID FROM Page WHERE name= ?");
			ps.setString(1, page);
			rs = ps.executeQuery();
			int pageID = -1;
			
			if(rs.next()){
				pageID = rs.getInt("pageID");
			}
			rs.close();
			ps = conn.prepareStatement("SELECT count FROM PageVisited WHERE userID = '"+userID+"' AND pageID='"+pageID+"'");
			rs = ps.executeQuery();
			if(rs.equals(null)){
				System.out.println("nothing returned");
			}
			int count = -1;
			if (rs.next()){
				count = rs.getInt("count");
			}
			rs.close();
			if(count >0){
				ps = conn.prepareStatement("UPDATE pageVisited pv SET pv.count = "+(count+1)+" WHERE userID = "+userID+" AND pageID = "+pageID);
			}else{
				ps = conn.prepareStatement("INSERT INTO pageVisited (userID, pageID, count) VALUES ('"+userID+"', '"+pageID+"', 1) ");
			}
			ps.executeUpdate();
		}catch(SQLException sqle){
			System.out.println("SQLException in function \"increment\"");
			sqle.printStackTrace();
		}
		finally{
			close();
		}
	}
	public static ArrayList<ArrayList<String> >getData(){
		ArrayList<ArrayList<String>>  stat = new ArrayList<ArrayList<String>>();
//		connect();
		try {
			conn = DriverManager.getConnection("jdbc:mysql://localhost/Lab10?user=root&password=root&useSSL=false");
			ps = conn.prepareStatement("SELECT u.username, p.name, pv.count FROM User u, Page p, PageVisited pv "
					+ "WHERE u.userID = pv.userID AND p.pageID = pv.pageID ORDER BY u.userID, p.pageID");
			rs = ps.executeQuery();
			while(rs.next()){
				ArrayList<String> row = new ArrayList<String>();
				row.add(rs.getString("u.username"));
				row.add(rs.getString("p.name"));
				row.add(rs.getString("pv.count"));
				stat.add(row);
			}
		}catch(SQLException sqle){
			System.out.println("SQLException in function \" getData\": ");
			sqle.printStackTrace();
		}finally{
			close();
		}
		return stat;
	}
	private static void println(String string) {
		System.out.println(string);		
	}
	private static void print(String string) {
		System.out.print(string);		
	}
	private static Course returnCourse(DataContainer data){
		return data.getSchools().get(0).getDepartments().get(0).getCourses().get(0);	
	}
	private static void addCourse(DataContainer data, Course c){
		data.getSchools().get(0).getDepartments().get(0).addCourse(c);
	}
}
