package servlets;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import parsing.Parser;
import objects.*;

/**
 * Servlet implementation class fileInput
 */
@WebServlet("/fileInput")
@MultipartConfig
public class fileInput extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public fileInput() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	 protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 
		 String next = "next page valid or invalid eg /validUsername.jsp";
    	 next = "/Home.jsp";
    	 
    	 Part filePart = request.getPart("fileName");
    	 if(filePart == null)
    	 {
    		 System.out.println("FILEPART IS NULL");
    	 }
    	 InputStream filecontent = null;
    	 filecontent = filePart.getInputStream();
    	 
    	 if(filecontent== null)
    	 {
    		 System.out.println("FILecontent IS NULL");
    	 }
    	 Parser parser = new Parser(filecontent);
    	 
//    	 String fname = request.getParameter("fname");
//    	 
//    	 if(fname.isEmpty())
//    	 {
//    		 request.setAttribute("name", "please enter name");
//    		 next = "/Form.html";
//    	 }
    	 School school = parser.getData().getSchools().get(0);
    	 
    	 HttpSession session = request.getSession();  
         session.setAttribute("school",school);
//         session.setMaxInactiveInterval(1); // 10 secs minutes 
         //if inactive ->response.sendRedirect
       
    	 
    	 
    	 request.setAttribute("school",school);
    	 RequestDispatcher dispatch = getServletContext().getRequestDispatcher(next);
    	 dispatch.forward(request,response);
    	 
	 }
		 

}
