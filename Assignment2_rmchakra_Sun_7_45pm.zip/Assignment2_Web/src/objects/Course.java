package objects;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Course {
	private String number;	
	private String title;
	private String units;
	private String term;
	private Integer year;
	private List<StaffMember> staffMembers;
	private List<Meeting> meetings;
	//meetings sorted into a map, key is the meeting type, value is a list of all meetings of that type
	private Map<String, List<Meeting>> sortedMeetings;
	//staff sorted into a map, key is the staff type, value is a list of all staff members of that type
	private Map<String, List<StaffMember>> sortedStaff;
	//map from staff member ID to staff member object
	private Map<Integer, StaffMember> staffMap;
	
	Syllabus syllabus;
	
	Schedule schedule;
	private List<Assignment> assignments;
	private List<Exam> exams;
	private ArrayList<ArrayList<ArrayList<StaffMember>>> ohMembers;//dince 5 days in week

	
	public Map<Integer, StaffMember> getStaffMap() {
		return staffMap;
	}
	public void setStaffMap(Map<Integer, StaffMember> staffMap) {
		this.staffMap = staffMap;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public Syllabus getSyllabus() {
		return syllabus;
	}
	public void setSyllabus(Syllabus syllabus) {
		this.syllabus = syllabus;
	}
	public String getUnits() {
		return units;
	}
	public void setUnits(String units) {
		this.units = units;
	}
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Course(){
		staffMembers = new ArrayList<>();
		meetings = new ArrayList<>();
		assignments = new ArrayList<>();
		exams = new ArrayList<>();
		ohMembers =  new ArrayList<ArrayList<ArrayList<StaffMember>>>(5);
		for (int i = 0; i < 5; i++) {
	        ArrayList<ArrayList<StaffMember>> inner = new ArrayList<ArrayList<StaffMember>>(6);
	        ohMembers.add(inner);
		}
	}
	
	public ArrayList<ArrayList<ArrayList<StaffMember>>> getOhMembers() {
		
		
		return ohMembers;
	}
	public void setOhMembers(ArrayList<ArrayList<ArrayList<StaffMember>>> ohMembers) {
		this.ohMembers = ohMembers;
	}
	public String getNumber(){
		return number;
	}
	
	public String getTerm(){
		return term;
	}
	
	public Integer getYear(){
		return year;
	}
	
	public List<StaffMember> getStaffMembers(){
		return staffMembers;
	}
	public List<Meeting> getMeetings(){
		return meetings;
	}
	public Map<String, List<Meeting>> getSortedMeetings(){
		if (sortedMeetings == null){
			//group the meetings by their type (by the method getMeetingType)
			sortedMeetings = meetings.stream().collect(Collectors.groupingBy(Meeting::getMeetingType));
		}
		return sortedMeetings;
	}
	public Map<String, List<StaffMember>> getSortedStaff(){
		if (sortedStaff == null){
			//group the staffMembers by their type (by the method getJobType)
			sortedStaff = staffMembers.stream().collect(Collectors.groupingBy(StaffMember::getJobType));
		}
		return sortedStaff;
	}
	public Map<Integer, StaffMember> getMappedStaff(){
		if (staffMap == null){
			staffMap = new HashMap<>();
			//create a map from the ID number to the StaffMember object
			staffMembers.stream().forEach(staff->{
				staffMap.put(staff.getID(), staff);
			});
		}
		return staffMap;
	}
	public List<Assignment> getAssignments() {
		return assignments;
	}
	public void setAssignments(List<Assignment> assignments) {
		this.assignments = assignments;
	}
	public List<Exam> getExams() {
		return exams;
	}
	public void setExams(List<Exam> exams) {
		this.exams = exams;
	}
	public Schedule getSchedule() {
		return schedule;
	}
	public void setSchedule(Schedule schedule) {
		this.schedule = schedule;
	}	
}
