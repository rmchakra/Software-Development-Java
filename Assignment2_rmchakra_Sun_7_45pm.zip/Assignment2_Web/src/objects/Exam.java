package objects;

import java.util.ArrayList;
import java.util.List;

public class Exam {
	public Exam() {
		tests = new ArrayList<>();
	}
	private String semester;
	private String year;
	private List<Test> tests;
	public String getSemester() {
		return semester;
	}
	public void setSemester(String semester) {
		this.semester = semester;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public List<Test> getTests() {
		return tests;
	}
	public void setTests(List<Test> tests) {
		this.tests = tests;
	}

}
