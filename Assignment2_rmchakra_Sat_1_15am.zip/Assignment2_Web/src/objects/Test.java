package objects;

import java.util.ArrayList;
import java.util.List;

public class Test {
	private String title;
	private List <File> files;
	public String getTitle() {
		return title;
	}
	public Test() {
		files = new ArrayList<>();
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<File> getFiles() {
		return files;
	}
	public void setFiles(List<File> files) {
		this.files = files;
	}

}
