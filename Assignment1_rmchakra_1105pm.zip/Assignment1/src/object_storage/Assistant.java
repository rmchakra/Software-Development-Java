package object_storage;

public class Assistant {
	public String name;//to be searched for within the school. Will not be provided while inputting
	public int staffMemberID;
	public Assistant(int staffMemberID, String name) {
		this.staffMemberID = staffMemberID;
		this.name = name;
	}
	public Assistant() {
		name ="";
	}

	
}
