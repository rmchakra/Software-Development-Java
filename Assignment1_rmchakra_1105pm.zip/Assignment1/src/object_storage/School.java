package object_storage;

import java.util.ArrayList;

public class School {
	public String name;
	public ArrayList<Department> departments;
	public School() {
		departments = new ArrayList<Department> ();
	}
	

}
