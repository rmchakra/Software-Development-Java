package object_storage;

public class Name {
	public String fName;
	public String lName;

}
