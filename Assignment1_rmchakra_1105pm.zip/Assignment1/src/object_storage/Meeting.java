package object_storage;

import java.util.ArrayList;

public class Meeting {
	public String type;
	public String section;
	public String room;
	public ArrayList<MeetingPeriod> meetingPeriods;
	public ArrayList<Assistant> assistants;//  =new ArrayList<Assistant>();
	public Meeting() {
		meetingPeriods = new ArrayList<MeetingPeriod> ();
		assistants = new ArrayList<Assistant> ();
	}
	public Meeting(String type, String section, String room, ArrayList<MeetingPeriod> meetingPeriod,
			ArrayList<Assistant> assistants) {
		this.type = type;
		this.section = section;
		this.room = room;
		this.meetingPeriods = meetingPeriod;
		this.assistants = assistants;
	}
	

}
