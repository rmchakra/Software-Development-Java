function test(){//is actually highlight staff
	var xhttp = new XMLHttpRequest();
	xhttp.open("GET", "test.jsp?staffMemberQuery="+document.searchStaff.staffMemberQuery.value, true);
		xhttp.send(); 
	
	
	xhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
		    
			  var ls = 	xhttp.responseText;	
			  document.getElementById("homeContent").innerHTML = ls;
				
				
		  }
		};

}
function clearFunc(){

	var xhttp = new XMLHttpRequest();
	
	xhttp.open("GET", "test.jsp?staffMemberQuery=999", true);
		xhttp.send(); 
	
	
	xhttp.onreadystatechange = function() {
		  if (this.readyState == 4 && this.status == 200) {
		    
			  var ls = 	xhttp.responseText;	
			  document.getElementById("homeContent").innerHTML = ls;
				
				
		  }
		};

}